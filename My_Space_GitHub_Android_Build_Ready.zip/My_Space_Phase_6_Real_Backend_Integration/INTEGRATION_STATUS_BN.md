# My Space — Integration Checkpoint

এই checkpoint-এ Supabase client alias, cloud profile loading/update, community poll create/list/vote/results এবং bookmarks helper যুক্ত করা হয়েছে। Existing social, messages, media/story/reel, notification ও admin UI adapters রাখা হয়েছে।

## Local checks
- `python tests/static_checks.py`
- `python tests/release_checks.py`

## এখনও যেসব live test বাকি
- Real signed-in account দিয়ে signup/login/email confirmation
- দুইটি আলাদা account দিয়ে friend request, accept, message ও read receipt
- Photo/video upload, private signed URL এবং story/reel playback
- Community poll vote ও duplicate-vote behavior
- Admin report review/verification (admin role-সহ test account প্রয়োজন)

## External dependency / not enabled
- `wafi-chat` Edge Function deploy করা হয়নি; function-এর জন্য server-side AI provider key প্রয়োজন। কোনো secret frontend-এ রাখা যাবে না।
- AI provider key ছাড়া WaFi কেবল local preview replies দেখায়; cloud AI চালু নয়।
- Supabase free plan-এর password leak protection warning remains; enable করতে plan upgrade লাগতে পারে।

## Android build
Capacitor config আছে, কিন্তু এই build environment-এ Android SDK/Gradle toolchain নেই এবং npm dependency installation timed out। তাই APK তৈরি হয়নি।
