// My Space Supabase configuration
// Publishable key only. Never put service_role or secret keys here.
window.MY_SPACE_SUPABASE_CONFIG = {
  url: "https://qtpjrhpowsuuaozyptdb.supabase.co",
  anonKey: "sb_publishable_IpzUSGbD4NIB-2PIUUPNhQ_AG8LxUit"
};
