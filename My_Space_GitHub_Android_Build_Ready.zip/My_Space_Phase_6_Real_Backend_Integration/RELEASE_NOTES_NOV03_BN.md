# My Space — ৩ নভেম্বর ২০২৬ আপডেট

- Fun Zone: একা খেলতে Memory Match, Quick Tap, Number Guess ও Quick Quiz।
- একই ডিভাইসে 1 বনাম 1: Tic Tac Toe এবং Rock Paper Scissors।
- Robot-এর বিরুদ্ধে: Tic Tac Toe (minimax bot) এবং Rock Paper Scissors।
- Explore → Movies & Series: ৫০টি Movie এবং ৫০টি Series, আলাদা তালিকা ও search।
- Explore → Music: বাংলা, হিন্দি ও ইংরেজি মিলিয়ে ৮০টি গানের title/artist discovery তালিকা।
- গান/সিনেমার কনটেন্ট কপি বা host করা হয়নি; প্রতিটি item থেকে YouTube/ওয়েব সার্চে বৈধ উৎস খুঁজে দেখা যায়।
- WaFi-এর free rules-based Edge Function আগের deploy-ই রয়েছে; এটি generative AI নয় এবং API charge করে না।
