from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
front=(root/'supabase-config.js').read_text()
assert not re.search(r'(?:service_role|OPENAI_API_KEY)\s*:\s*["\'](?!YOUR_|SET_ONLY)', front, re.I)
assert 'sb_publishable_' in front or 'YOUR_SUPABASE_ANON_PUBLIC_KEY' in front
wafi=(root/'supabase/functions/wafi-chat/index.ts').read_text()
assert '.eq("user_approved", true)' in wafi
assert '.eq("user_id", user.id)' in wafi
assert '.from("messages")' not in wafi and '.from("media_items")' not in wafi
sql=(root/'supabase/migrations/003_phase6_media_stories_notifications_admin.sql').read_text().lower()
for table in ['stories','story_views','reels','reel_likes','notifications','admin_audit_log','wafi_rate_limits']:
    assert f'alter table public.{table} enable row level security' in sql, table
assert "profile_visibility text not null default 'private'" in sql
assert "values('my-space-media','my-space-media',false" in sql
assert 'admin_review_report' in sql and 'admin_audit_log' in sql
assert 'media_shared_select' in sql
print('PASS: frontend secret separation, approved-memory filter, private bucket, RLS, profile privacy, shared-media access, admin audit static checks')
