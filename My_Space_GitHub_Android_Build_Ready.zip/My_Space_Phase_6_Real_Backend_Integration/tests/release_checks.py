from pathlib import Path
import json,re,subprocess,sys
R=Path(__file__).resolve().parents[1]
required=['index.html','app.js','styles.css','supabase-config.js','supabase-bridge.js','wafi-bridge.js','media-bridge.js','social-plus-bridge.js','cloud-features-bridge.js','sw.js','manifest.webmanifest','capacitor.config.json','supabase/migrations/004_phase7_security_privacy_hardening.sql','supabase/functions/wafi-chat/index.ts','supabase/functions/media-access/index.ts','supabase/functions/admin-actions/index.ts']
missing=[x for x in required if not (R/x).exists()]
assert not missing, f'Missing files: {missing}'
config=(R/'supabase-config.js').read_text()
assert 'sb_publishable_' in config or 'YOUR_SUPABASE_ANON_PUBLIC_KEY' in config
assert not re.search(r'(service_role|OPENAI_API_KEY)\s*[:=]\s*["\'](?!YOUR_|SET_ONLY)',config,re.I)
assert 'mySpaceSupabase=client' in (R/'supabase-bridge.js').read_text()
for p in (R/'supabase/functions').rglob('index.ts'):
 s=p.read_text(); assert 'SUPABASE_SERVICE_ROLE_KEY' not in s or 'Deno.env.get' in s, f'Unsafe service role handling: {p}'
for p in (R/'supabase/functions').rglob('index.ts'):
 assert 'verify_jwt = true' in (R/'supabase/config.toml').read_text()
m=json.loads((R/'manifest.webmanifest').read_text()); assert m['name']=='My Space' and m['display']=='standalone'
assert (R/'icons/icon-192.svg').exists() and (R/'icons/icon-512.svg').exists()
sw=(R/'sw.js').read_text(); assert '/auth/' in sw and '/rest/' in sw and '/functions/' in sw
sql=(R/'supabase/migrations/004_phase7_security_privacy_hardening.sql').read_text().lower()
assert 'revoke update (is_verified)' in sql and 'public.admin_audit_log' in sql
if subprocess.run(['bash','-lc','command -v node >/dev/null 2>&1']).returncode==0:
 for f in ['app.js','supabase-bridge.js','social-bridge.js','wafi-bridge.js','media-bridge.js','social-plus-bridge.js','phase6-ui.js','cloud-features-bridge.js','sw.js']:
  q=subprocess.run(['node','--check',str(R/f)],capture_output=True,text=True)
  assert q.returncode==0, f'JS syntax failed {f}: {q.stderr}'
cloud=(R/'cloud-features-bridge.js').read_text(); assert 'createPoll' in cloud and 'updateProfile' in cloud and 'pollResults' in cloud
assert 'myspace:profile-loaded' in (R/'supabase-bridge.js').read_text()
print('PASS: required files, public-key-only frontend config, Edge Function config, cloud profile/polls/bookmarks, manifest, PWA cache exclusions, security migration, JS syntax')
