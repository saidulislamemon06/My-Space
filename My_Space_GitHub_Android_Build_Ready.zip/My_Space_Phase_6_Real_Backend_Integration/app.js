(() => {
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const store = {
    get(key, fallback) { try { const v=localStorage.getItem('myspace_'+key); return v ? JSON.parse(v) : fallback; } catch { return fallback; } },
    set(key, value) { try { localStorage.setItem('myspace_'+key, JSON.stringify(value)); } catch {} },
    del(key) { try { localStorage.removeItem('myspace_'+key); } catch {} }
  };
  let posts = store.get('posts', []);
  let saved = store.get('saved', []);
  let profile = store.get('profile', {name:'My Profile', bio:'Your story starts here.'});
  let votes = store.get('votes', {});
  const pageNames = {home:'Home',profile:'My Profile',explore:'Explore',messages:'Messages',wafi:'WaFi AI',fun:'Fun Zone',friends:'Friends',gallery:'Gallery & Memories',notifications:'Notifications',settings:'Settings',create:'Create Post',polls:'Polls & Surveys',vibes:'My Vibes',saved:'Saved Items',privacy:'Privacy & Security'};
  function showPage(name) {
    if (!pageNames[name]) name='home';
    $$('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+name));
    $$('[data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page===name));
    $('#page-heading').textContent=pageNames[name];
    window.scrollTo({top:0,behavior:'smooth'});
    if(name==='saved') renderSaved();
    if(name==='profile') renderProfile();
  }
  document.addEventListener('click', e=>{
    const nav=e.target.closest('[data-page]');
    if(nav){e.preventDefault();showPage(nav.dataset.page);}
  });
  const themeSelect=$('#theme-select'), themeToggle=$('#theme-toggle');
  function setTheme(v){document.body.classList.toggle('light',v==='light'); if(themeSelect)themeSelect.value=v;store.set('theme',v);}
  setTheme(store.get('theme','dark'));
  themeSelect?.addEventListener('change',e=>setTheme(e.target.value==='system'?(matchMedia('(prefers-color-scheme: light)').matches?'light':'dark'):e.target.value));
  themeToggle?.addEventListener('click',()=>setTheme(document.body.classList.contains('light')?'dark':'light'));

  function safeText(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function postCard(post, withSave=true){
    const isSaved=saved.some(x=>x.id===post.id);
    return `<article class="post-card"><div class="post-meta"><strong>${safeText(post.author||profile.name)}</strong><time>${new Date(post.time).toLocaleString()}</time></div><p>${safeText(post.text)}</p><div class="post-actions">${withSave?`<button data-save="${post.id}">${isSaved?'★ Saved':'☆ Save'}</button>`:''}<span>Local demo post</span></div></article>`;
  }
  function renderPosts(){
    const feed=$('#feed-posts'); if(feed)feed.innerHTML=posts.length?posts.slice().reverse().map(p=>postCard(p)).join(''):'<p class="muted">এখনো কোনো পোস্ট নেই।</p>';
    const profileFeed=$('#profile-posts'); if(profileFeed)profileFeed.innerHTML=posts.length?posts.slice().reverse().map(p=>postCard(p)).join(''):'<p class="muted">তোমার প্রথম পোস্টটি তৈরি করো।</p>';
    const count=$('#post-count'); if(count)count.textContent=posts.length;
  }
  document.addEventListener('myspace:profile-loaded',e=>{
    const d=e.detail||{};profile={name:String(d.display_name||'My Space User'),bio:String(d.bio||'')};store.set('profile',profile);renderProfile();
  });
  function renderProfile(){
    $('#profile-name').textContent=profile.name;
    $('#profile-handle').textContent='@'+profile.name.toLowerCase().replace(/[^a-z0-9]+/g,'')+' · Your personal space';
    $('#profile-bio').textContent=profile.bio;
    $('#profile-avatar').textContent=(profile.name.trim()[0]||'M').toUpperCase();
    renderPosts();
  }
  $('#edit-profile')?.addEventListener('click',()=>{
    const name=prompt('তোমার Profile Name লিখো:',profile.name); if(name===null)return;
    const bio=prompt('এক লাইনের Bio লিখো:',profile.bio); if(bio===null)return;
    profile={name:name.trim().slice(0,32)||'My Profile',bio:bio.trim().slice(0,160)||'Your story starts here.'};
    store.set('profile',profile);renderProfile();
  });
  const postText=$('#post-text'), charCount=$('#char-count');
  postText?.addEventListener('input',()=>charCount.textContent=`${postText.value.length} / 1000`);
  $('#publish-post')?.addEventListener('click',()=>{
    const text=postText.value.trim(); if(!text){alert('আগে কিছু লিখো।');return;}
    posts.push({id:Date.now().toString(),text,author:profile.name,time:new Date().toISOString()});
    store.set('posts',posts);postText.value='';charCount.textContent='0 / 1000';renderPosts();showPage('create');
  });
  document.addEventListener('click',e=>{
    const b=e.target.closest('[data-save]');if(!b)return;
    const post=posts.find(p=>p.id===b.dataset.save);if(!post)return;
    if(saved.some(p=>p.id===post.id))saved=saved.filter(p=>p.id!==post.id);else saved.push(post);
    store.set('saved',saved);renderPosts();renderSaved();
  });
  function renderSaved(){const el=$('#saved-list');if(el)el.innerHTML=saved.length?saved.slice().reverse().map(p=>postCard(p,false)).join(''):'<div class="empty-state"><span>▣</span><h3>কিছু সংরক্ষণ করা হয়নি</h3><p>পোস্ট থেকে ☆ Save চাপলে এখানে দেখা যাবে।</p></div>';}
  $('#poll-options')?.addEventListener('click',e=>{
    const b=e.target.closest('[data-vote]');if(!b)return;
    votes.today=b.dataset.vote;store.set('votes',votes);
    $('#poll-result').textContent='তোমার ভোট: '+votes.today+' — ডেমো ভোট শুধু এই ডিভাইসে থাকে।';
    $$('#poll-options button').forEach(x=>x.classList.toggle('chosen',x===b));
  });
  if(votes.today){$('#poll-result').textContent='তোমার ভোট: '+votes.today+' — ডেমো ভোট শুধু এই ডিভাইসে থাকে।';$$('#poll-options button').forEach(x=>x.classList.toggle('chosen',x.dataset.vote===votes.today));}
  $('#create-poll')?.addEventListener('click',async()=>{
    const q=$('#poll-question').value.trim(),a=$('#poll-choice1').value.trim(),b=$('#poll-choice2').value.trim();
    if(!q||!a||!b){$('#poll-created').textContent='প্রশ্ন ও দুটি অপশন পূরণ করো।';return;}
    try {
      if(window.mySpaceSupabaseClient && window.MySpaceCloudFeatures){
        const {data:{user}}=await window.mySpaceSupabaseClient.auth.getUser();
        if(user){await window.MySpaceCloudFeatures.createPoll(q,[a,b]);$('#poll-created').textContent='Community poll তৈরি হয়েছে।';document.dispatchEvent(new CustomEvent('myspace:polls-refresh'));}
        else $('#poll-created').textContent=`ডেমো পোল: ${q} (${a} / ${b}) — Sign in করলে Community-তে প্রকাশ করতে পারবে।`;
      } else $('#poll-created').textContent=`ডেমো পোল: ${q} (${a} / ${b})`;
    } catch(e){$('#poll-created').textContent=e.message||'Poll তৈরি করা যায়নি।';return;}
    $('#poll-question').value=$('#poll-choice1').value=$('#poll-choice2').value='';
  });
  $('#save-vibes')?.addEventListener('click',()=>{
    const data={};$$('.vibe-input').forEach(i=>data[i.dataset.vibe]=i.value.trim());store.set('vibes',data);$('#vibe-status').textContent='এই ডিভাইসে সেভ হয়েছে।';
  });
  const vibes=store.get('vibes',{});$$('.vibe-input').forEach(i=>i.value=vibes[i.dataset.vibe]||'');
  $('#clear-local')?.addEventListener('click',()=>{
    if(!confirm('এই ডিভাইসের My Space ডেমো পোস্ট, প্রোফাইল, পোল ও পছন্দ মুছবে। নিশ্চিত?'))return;
    ['posts','saved','profile','votes','vibes'].forEach(store.del);posts=[];saved=[];profile={name:'My Profile',bio:'Your story starts here.'};votes={};renderPosts();renderProfile();renderSaved();$('#clear-status').textContent='ডেমো ডেটা মুছে ফেলা হয়েছে।';
  });

  // WaFi offline preview: transparent, rule-based sample replies; no external AI connection.
  const chat=$('#page-wafi');
  if(chat){
    const box=$('.chat-disabled',chat);
    if(box){box.className='chat-input-row';box.innerHTML='<input id="wafi-input" aria-label="Message WaFi" placeholder="WaFi-কে কিছু জিজ্ঞেস করো..."><button id="wafi-send">Send</button>';}
    const suggestions=$('.suggestions',chat);
    suggestions?.addEventListener('click',e=>{const b=e.target.closest('button');if(b)sendWaFi(b.textContent);});
    $('#wafi-send')?.addEventListener('click',()=>sendWaFi($('#wafi-input').value));
    $('#wafi-input')?.addEventListener('keydown',e=>{if(e.key==='Enter')sendWaFi(e.target.value);});
    function sendWaFi(value){
      const v=String(value||'').trim();if(!v)return;
      let answer='আমি এখন My Space-এর অফলাইন প্রিভিউ মোডে আছি। বাস্তব AI উত্তর পেতে নিরাপদ Backend ও AI API সংযোগ করতে হবে।';
      if(/caption|ক্যাপশন/i.test(v))answer='ক্যাপশন আইডিয়া: “ছোট ছোট মুহূর্তেই তৈরি হয় সুন্দর স্মৃতি।” চাইলে পোস্টের বিষয় বলো, আমি আরও আইডিয়া সাজিয়ে দিতে পারি।';
      else if(/quiz|কুইজ/i.test(v))answer='মিনি কুইজ: বাংলাদেশের জাতীয় ফুল কোনটি? ক) গোলাপ খ) শাপলা গ) জুঁই — উত্তর: খ) শাপলা।';
      else if(/idea|আইডিয়া/i.test(v))answer='আইডিয়া: My Space-এ “আজকের প্রশ্ন” নামে একটি দৈনিক কমিউনিটি প্রশ্ন চালু করতে পারো।';
      const area=$('.wafi-chat',chat);let log=$('#wafi-log');if(!log){log=document.createElement('div');log.id='wafi-log';log.className='chat-log';area.appendChild(log);}
      log.insertAdjacentHTML('beforeend',`<div class="chat-bubble user">${safeText(v)}</div><div class="chat-bubble bot">${safeText(answer)}</div>`);
      $('#wafi-input').value='';
    }
  }
  // Fun Zone: single-player, local 1v1, and versus-robot games.
  const fun=$('#page-fun');
  if(fun){
    const stage=$('#game-stage');
    let current='memory', memory=[], opened=[], matched=0, locked=false, target=0, timer=null;
    let board=Array(9).fill(''), turn='X', rpsFirst=null, quizIndex=0, quizScore=0;
    const symbols=['🍀','🚀','🎧','⭐','🐼','⚽'];
    const wins=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
    const quizzes=[
      ['বাংলাদেশের জাতীয় ফুল কোনটি?',['গোলাপ','শাপলা','জুঁই'],1],
      ['পৃথিবীর সবচেয়ে বড় মহাসাগর কোনটি?',['প্রশান্ত মহাসাগর','আটলান্টিক','ভারত মহাসাগর'],0],
      ['এক সপ্তাহে কয় দিন?',['৫','৬','৭'],2],
      ['সূর্যের সবচেয়ে কাছের গ্রহ কোনটি?',['শুক্র','বুধ','মঙ্গল'],1],
      ['বাংলাদেশের জাতীয় ফল কোনটি?',['আম','কাঁঠাল','লিচু'],1],
      ['মানুষের শরীরে রক্ত পাম্প করে কোন অঙ্গ?',['ফুসফুস','হৃদপিণ্ড','কিডনি'],1]
    ];
    function setStatus(t){const el=$('#game-status',stage);if(el)el.textContent=t;}
    function resetMemory(){
      memory=[...symbols,...symbols].sort(()=>Math.random()-.5);opened=[];matched=0;locked=false;
      stage.innerHTML='<h3>🧠 Memory Match · একা খেলো</h3><p class="muted">একই রকম দুইটি কার্ড খুঁজে বের করো।</p><div id="memory-board" class="memory-board">'+memory.map((v,i)=>`<button class="memory-card" data-memory="${i}" aria-label="Card ${i+1}">?</button>`).join('')+'</div><p id="game-status" class="game-status" aria-live="polite">মিল খুঁজে বের করো · ০/৬ জোড়া</p><button class="secondary-btn" id="game-reset">নতুন গেম</button>';
    }
    function resetQuick(){
      clearTimeout(timer);
      stage.innerHTML='<h3>⚡ Quick Tap · একা খেলো</h3><p class="muted">Start চাপো। সবুজ হলে যত দ্রুত পারো Tap করো।</p><button class="primary-btn" id="quick-start">Start</button><button class="reaction-pad" id="quick-pad" disabled>READY?</button><p id="game-status" class="game-status">তোমার reaction time মাপো।</p><button class="secondary-btn" id="game-reset">আবার খেলো</button>';
    }
    function resetNumber(){
      target=Math.floor(Math.random()*50)+1;
      stage.innerHTML='<h3>🔢 Number Guess · একা খেলো</h3><p class="muted">১ থেকে ৫০-এর মধ্যে সংখ্যাটি অনুমান করো।</p><div class="number-row"><input id="number-guess" class="field" type="number" min="1" max="50" placeholder="১–৫০"><button class="primary-btn" id="number-submit">Guess</button></div><p id="game-status" class="game-status">তোমার অনুমান লিখো।</p><button class="secondary-btn" id="game-reset">নতুন সংখ্যা</button>';
    }
    function resetQuiz(){
      quizIndex=0;quizScore=0;renderQuiz();
    }
    function renderQuiz(){
      const q=quizzes[quizIndex];
      if(!q){stage.innerHTML=`<h3>🏆 Quiz শেষ!</h3><p class="game-status">তোমার স্কোর ${quizScore}/${quizzes.length}</p><button class="primary-btn" id="quiz-again">আবার খেলো</button>`;return;}
      stage.innerHTML=`<h3>🧩 Quick Quiz · একা খেলো</h3><p class="muted">প্রশ্ন ${quizIndex+1}/${quizzes.length} · স্কোর ${quizScore}</p><h4>${q[0]}</h4><div class="quiz-options">${q[1].map((a,i)=>`<button class="secondary-btn" data-quiz="${i}">${a}</button>`).join('')}</div><p id="game-status" class="game-status">সঠিক উত্তর বেছে নাও।</p>`;
    }
    function checkWinner(b){return wins.find(w=>b[w[0]]&&b[w[0]]===b[w[1]]&&b[w[1]]===b[w[2]])?.map(i=>b[i])[0]||null;}
    function scoreMove(b,player){
      const winner=checkWinner(b);
      if(winner)return winner===player?10:-10;
      if(b.every(Boolean))return 0;
      const scores=[];
      b.forEach((v,i)=>{if(!v){b[i]=player;scores.push(scoreMove(b,player==='O'?'X':'O'));b[i]='';}});
      return player==='O'?Math.max(...scores)-1:Math.min(...scores)+1;
    }
    function bestBotMove(){
      let best=-Infinity, choice=-1;
      board.forEach((v,i)=>{if(!v){board[i]='O';const s=scoreMove(board,'O');board[i]='';if(s>best){best=s;choice=i;}}});
      return choice;
    }
    function renderTtt(){
      const mode=current==='ttt-bot'?'vs Robot':'1 বনাম 1';
      stage.innerHTML=`<h3>⭕ Tic Tac Toe · ${mode}</h3><p class="muted">${current==='ttt-bot'?'তুমি X, Robot O':'একই ডিভাইসে দুইজন খেলো · X বনাম O'}</p><div id="ttt-board" class="ttt-board">${board.map((v,i)=>`<button data-cell="${i}" aria-label="ঘর ${i+1}">${v}</button>`).join('')}</div><p id="game-status" class="game-status">${current==='ttt-bot'?(turn==='X'?'তোমার চাল: X':'Robot-এর চাল: O'):(turn==='X'?'X-এর চাল':'O-এর চাল')}</p><button class="secondary-btn" id="game-reset">নতুন ম্যাচ</button>`;
    }
    function resetTtt(){board=Array(9).fill('');turn='X';renderTtt();}
    function finishTtt(){
      const winner=checkWinner(board);
      if(winner){setStatus(winner==='X'?'X জিতেছে! 🎉':current==='ttt-bot'?'Robot জিতেছে। আবার চেষ্টা করো!':'O জিতেছে! 🎉');return true;}
      if(board.every(Boolean)){setStatus('ম্যাচ ড্র হয়েছে!');return true;}
      return false;
    }
    function playTtt(index){
      if(board[index]||finishTtt())return;
      board[index]=turn;
      if(finishTtt()){renderTtt();finishTtt();return;}
      if(current==='ttt-bot'){
        turn='O';renderTtt();
        const move=bestBotMove();if(move>=0)board[move]='O';
        turn='X';renderTtt();finishTtt();
      }else{
        turn=turn==='X'?'O':'X';renderTtt();
      }
    }
    function resetRps(){
      rpsFirst=null;
      stage.innerHTML=`<h3>✊ Rock · Paper · Scissors · ${current==='rps-bot'?'vs Robot':'1 বনাম 1'}</h3><p class="muted">${current==='rps-bot'?'তুমি Robot-এর বিরুদ্ধে খেলবে।':'একই ডিভাইসে দুইজন খেলো। প্রথম খেলোয়াড় বেছে নাও।'}</p><div class="rps-options">${[['rock','✊','Rock'],['paper','✋','Paper'],['scissors','✌️','Scissors']].map(x=>`<button class="secondary-btn" data-rps="${x[0]}">${x[1]} ${x[2]}</button>`).join('')}</div><p id="game-status" class="game-status">তোমার পছন্দ বেছে নাও।</p><button class="secondary-btn" id="game-reset">নতুন রাউন্ড</button>`;
    }
    function rpsResult(a,b){
      if(a===b)return 'ড্র!';
      return (a==='rock'&&b==='scissors')||(a==='paper'&&b==='rock')||(a==='scissors'&&b==='paper')?'জিতেছে!':'হেরেছে!';
    }
    function chooseGame(name){
      current=name;$$('[data-game]',fun).forEach(b=>b.classList.toggle('active',b.dataset.game===name));
      if(name==='memory')resetMemory();
      else if(name==='quick')resetQuick();
      else if(name==='number')resetNumber();
      else if(name==='quiz')resetQuiz();
      else if(name==='ttt-bot'||name==='ttt-2p')resetTtt();
      else resetRps();
    }
    fun.addEventListener('click',e=>{
      const pick=e.target.closest('[data-game]');if(pick){chooseGame(pick.dataset.game);return;}
      if(e.target.closest('#game-reset')){chooseGame(current);return;}
      if(e.target.id==='quiz-again'){resetQuiz();return;}
      if(current==='memory'){
        const b=e.target.closest('[data-memory]');if(!b||locked||b.classList.contains('matched')||b.classList.contains('revealed'))return;
        const i=+b.dataset.memory;b.textContent=memory[i];b.classList.add('revealed');opened.push(b);
        if(opened.length===2){locked=true;if(memory[+opened[0].dataset.memory]===memory[+opened[1].dataset.memory]){opened.forEach(x=>x.classList.add('matched'));matched++;setStatus(`দারুণ! ${matched}/৬ জোড়া মিলেছে`);opened=[];locked=false;if(matched===6)setStatus('🎉 সব জোড়া মিলে গেছে!');}else setTimeout(()=>{opened.forEach(x=>{x.textContent='?';x.classList.remove('revealed');});opened=[];locked=false;},650);}
      }
      if(current==='quick'){
        if(e.target.id==='quick-start'){const pad=$('#quick-pad');pad.disabled=true;pad.textContent='WAIT...';pad.classList.remove('go');setStatus('সবুজ হওয়া পর্যন্ত অপেক্ষা করো...');timer=setTimeout(()=>{pad.disabled=false;pad.textContent='TAP NOW!';pad.classList.add('go');pad.dataset.started=Date.now();},1000+Math.random()*2500);}
        else if(e.target.id==='quick-pad'&&!e.target.disabled){if(!e.target.dataset.started){setStatus('আগে Start চাপো।');return;}const ms=Date.now()-Number(e.target.dataset.started);e.target.disabled=true;e.target.textContent='DONE';setStatus(`তোমার reaction time ${ms} ms`);}
      }
      if(current==='number'&&e.target.id==='number-submit'){const n=Number($('#number-guess').value);if(!Number.isInteger(n)||n<1||n>50){setStatus('১ থেকে ৫০-এর একটি পূর্ণসংখ্যা দাও।');return;}setStatus(n===target?'🎉 সঠিক! তুমি পেরেছ।':n<target?'আরও বড় সংখ্যা চেষ্টা করো।':'আরও ছোট সংখ্যা চেষ্টা করো।');if(n===target)$('#number-submit').disabled=true;}
      if(current==='quiz'&&e.target.hasAttribute('data-quiz')){const selected=Number(e.target.dataset.quiz),q=quizzes[quizIndex];if(selected===q[2])quizScore++;quizIndex++;renderQuiz();}
      if((current==='ttt-bot'||current==='ttt-2p')&&e.target.hasAttribute('data-cell')){playTtt(Number(e.target.dataset.cell));}
      if((current==='rps-bot'||current==='rps-2p')&&e.target.hasAttribute('data-rps')){
        const choice=e.target.dataset.rps;
        if(current==='rps-bot'){const bot=['rock','paper','scissors'][Math.floor(Math.random()*3)];const labels={rock:'✊ Rock',paper:'✋ Paper',scissors:'✌️ Scissors'};setStatus(`তুমি: ${labels[choice]} · Robot: ${labels[bot]} · ${rpsResult(choice,bot)}`);}
        else if(!rpsFirst){rpsFirst=choice;stage.innerHTML='<h3>✊ Rock · Paper · Scissors · 1 বনাম 1</h3><p class="muted">এবার দ্বিতীয় খেলোয়াড়কে ডিভাইস দাও। সে নিজের পছন্দ বেছে নিক।</p><div class="rps-options">'+[['rock','✊','Rock'],['paper','✋','Paper'],['scissors','✌️','Scissors']].map(x=>`<button class="secondary-btn" data-rps="${x[0]}">${x[1]} ${x[2]}</button>`).join('')+'</div><p id="game-status" class="game-status">Player 2-এর পালা।</p><button class="secondary-btn" id="game-reset">নতুন রাউন্ড</button>';}
        else{const labels={rock:'✊ Rock',paper:'✋ Paper',scissors:'✌️ Scissors'};const result=rpsResult(rpsFirst,choice);setStatus(`Player 1: ${labels[rpsFirst]} · Player 2: ${labels[choice]} · ${result==='ড্র!'?'ড্র!':result==='জিতেছে!'?'Player 1 জিতেছে!':'Player 2 জিতেছে!'}`);rpsFirst=null;}
      }
    });
    chooseGame('memory');
  }

  // Curated discovery cards; external links open official search/catalog pages.
  const exploreData={
    gaming:[['🎮','Puzzle & Brain','ধাঁধা, লজিক ও ব্রেইন গেম','https://www.google.com/search?q=free+browser+puzzle+games'],['🏎️','Racing','ড্রাইভিং ও রেসিং গেম','https://www.google.com/search?q=free+browser+racing+games'],['⚽','Sports Games','ফুটবল, ক্রিকেট ও স্পোর্টস','https://www.google.com/search?q=free+browser+sports+games'],['🧩','Casual Games','ছোট বিরতির সহজ গেম','https://www.google.com/search?q=free+casual+browser+games']],
    music:[
["🎵","Amar Bhindeshi Tara","Chandrabindoo · Bangla","https://www.youtube.com/results?search_query=Amar+Bhindeshi+Tara+Chandrabindoo+official+audio"],
["🎵","Bojhena Shey Bojhena","Arijit Singh · Bangla","https://www.youtube.com/results?search_query=Bojhena+Shey+Bojhena+Arijit+Singh+official+audio"],
["🎵","Tomake Chai","Arijit Singh · Bangla","https://www.youtube.com/results?search_query=Tomake+Chai+Arijit+Singh+official+audio"],
["🎵","Amake Amar Moto Thakte Dao","Anupam Roy · Bangla","https://www.youtube.com/results?search_query=Amake+Amar+Moto+Thakte+Dao+Anupam+Roy+official+audio"],
["🎵","Ekhon Onek Raat","Anupam Roy · Bangla","https://www.youtube.com/results?search_query=Ekhon+Onek+Raat+Anupam+Roy+official+audio"],
["🎵","Benche Thakar Gaan","Anupam Roy · Bangla","https://www.youtube.com/results?search_query=Benche+Thakar+Gaan+Anupam+Roy+official+audio"],
["🎵","Shey Je Boshe Ache","Arnob · Bangla","https://www.youtube.com/results?search_query=Shey+Je+Boshe+Ache+Arnob+official+audio"],
["🎵","Hariye Giyechi","Arnob · Bangla","https://www.youtube.com/results?search_query=Hariye+Giyechi+Arnob+official+audio"],
["🎵","Ami Banglay Gaan Gai","Pratul Mukhopadhyay · Bangla","https://www.youtube.com/results?search_query=Ami+Banglay+Gaan+Gai+Pratul+Mukhopadhyay+official+audio"],
["🎵","Majhe Majhe Tobo","Rabindra Sangeet · Bangla","https://www.youtube.com/results?search_query=Majhe+Majhe+Tobo+Rabindra+Sangeet+official+audio"],
["🎵","Purano Shei Diner Kotha","Rabindra Sangeet · Bangla","https://www.youtube.com/results?search_query=Purano+Shei+Diner+Kotha+Rabindra+Sangeet+official+audio"],
["🎵","Tumi Robe Nirobe","Rabindra Sangeet · Bangla","https://www.youtube.com/results?search_query=Tumi+Robe+Nirobe+Rabindra+Sangeet+official+audio"],
["🎵","Amar Shonar Bangla","Traditional · Bangla","https://www.youtube.com/results?search_query=Amar+Shonar+Bangla+Traditional+official+audio"],
["🎵","Aaj Jyotsna Raate","Rabindra Sangeet · Bangla","https://www.youtube.com/results?search_query=Aaj+Jyotsna+Raate+Rabindra+Sangeet+official+audio"],
["🎵","Oporadhi","Arman Alif · Bangla","https://www.youtube.com/results?search_query=Oporadhi+Arman+Alif+official+audio"],
["🎵","Oniket Prantor","Artcell · Bangla","https://www.youtube.com/results?search_query=Oniket+Prantor+Artcell+official+audio"],
["🎵","Dukkho Bilash","Artcell · Bangla","https://www.youtube.com/results?search_query=Dukkho+Bilash+Artcell+official+audio"],
["🎵","Poth Chola","Warfaze · Bangla","https://www.youtube.com/results?search_query=Poth+Chola+Warfaze+official+audio"],
["🎵","Obak Bhalobasha","Warfaze · Bangla","https://www.youtube.com/results?search_query=Obak+Bhalobasha+Warfaze+official+audio"],
["🎵","Maa","James · Bangla","https://www.youtube.com/results?search_query=Maa+James+official+audio"],
["🎵","Baba","James · Bangla","https://www.youtube.com/results?search_query=Baba+James+official+audio"],
["🎵","Lal Shari","Habib Wahid · Bangla","https://www.youtube.com/results?search_query=Lal+Shari+Habib+Wahid+official+audio"],
["🎵","Krishno","Habib Wahid · Bangla","https://www.youtube.com/results?search_query=Krishno+Habib+Wahid+official+audio"],
["🎵","Din Gelo","Habib Wahid · Bangla","https://www.youtube.com/results?search_query=Din+Gelo+Habib+Wahid+official+audio"],
["🎵","Abar Hashimukh","Shironamhin · Bangla","https://www.youtube.com/results?search_query=Abar+Hashimukh+Shironamhin+official+audio"],
["🎵","Pakhi","Shironamhin · Bangla","https://www.youtube.com/results?search_query=Pakhi+Shironamhin+official+audio"],
["🎵","Ei Obelay","Shironamhin · Bangla","https://www.youtube.com/results?search_query=Ei+Obelay+Shironamhin+official+audio"],
["🎵","Bondho Janala","Shironamhin · Bangla","https://www.youtube.com/results?search_query=Bondho+Janala+Shironamhin+official+audio"],
["🎵","Mon Majhi Re","Arijit Singh · Bangla","https://www.youtube.com/results?search_query=Mon+Majhi+Re+Arijit+Singh+official+audio"],
["🎵","Tumi Jake Bhalobasho","Iman Chakraborty · Bangla","https://www.youtube.com/results?search_query=Tumi+Jake+Bhalobasho+Iman+Chakraborty+official+audio"],
["🎵","Kesariya","Arijit Singh · Hindi","https://www.youtube.com/results?search_query=Kesariya+Arijit+Singh+official+audio"],
["🎵","Tum Hi Ho","Arijit Singh · Hindi","https://www.youtube.com/results?search_query=Tum+Hi+Ho+Arijit+Singh+official+audio"],
["🎵","Channa Mereya","Arijit Singh · Hindi","https://www.youtube.com/results?search_query=Channa+Mereya+Arijit+Singh+official+audio"],
["🎵","Agar Tum Saath Ho","Alka Yagnik & Arijit Singh · Hindi","https://www.youtube.com/results?search_query=Agar+Tum+Saath+Ho+Alka+Yagnik+%26+Arijit+Singh+official+audio"],
["🎵","Kal Ho Naa Ho","Sonu Nigam · Hindi","https://www.youtube.com/results?search_query=Kal+Ho+Naa+Ho+Sonu+Nigam+official+audio"],
["🎵","Kun Faya Kun","A.R. Rahman · Hindi","https://www.youtube.com/results?search_query=Kun+Faya+Kun+A.R.+Rahman+official+audio"],
["🎵","Ilahi","Arijit Singh · Hindi","https://www.youtube.com/results?search_query=Ilahi+Arijit+Singh+official+audio"],
["🎵","Safarnama","Lucky Ali · Hindi","https://www.youtube.com/results?search_query=Safarnama+Lucky+Ali+official+audio"],
["🎵","Apna Bana Le","Arijit Singh · Hindi","https://www.youtube.com/results?search_query=Apna+Bana+Le+Arijit+Singh+official+audio"],
["🎵","Raataan Lambiyan","Jubin Nautiyal & Asees Kaur · Hindi","https://www.youtube.com/results?search_query=Raataan+Lambiyan+Jubin+Nautiyal+%26+Asees+Kaur+official+audio"],
["🎵","Shayad","Arijit Singh · Hindi","https://www.youtube.com/results?search_query=Shayad+Arijit+Singh+official+audio"],
["🎵","Phir Le Aya Dil","Arijit Singh · Hindi","https://www.youtube.com/results?search_query=Phir+Le+Aya+Dil+Arijit+Singh+official+audio"],
["🎵","Tera Ban Jaunga","Akhil & Tulsi Kumar · Hindi","https://www.youtube.com/results?search_query=Tera+Ban+Jaunga+Akhil+%26+Tulsi+Kumar+official+audio"],
["🎵","Galliyan","Ankit Tiwari · Hindi","https://www.youtube.com/results?search_query=Galliyan+Ankit+Tiwari+official+audio"],
["🎵","Kabira","Tochi Raina & Rekha Bhardwaj · Hindi","https://www.youtube.com/results?search_query=Kabira+Tochi+Raina+%26+Rekha+Bhardwaj+official+audio"],
["🎵","Zinda","Siddharth Mahadevan · Hindi","https://www.youtube.com/results?search_query=Zinda+Siddharth+Mahadevan+official+audio"],
["🎵","Jai Ho","A.R. Rahman · Hindi","https://www.youtube.com/results?search_query=Jai+Ho+A.R.+Rahman+official+audio"],
["🎵","Chaiyya Chaiyya","Sukhwinder Singh & Sapna Awasthi · Hindi","https://www.youtube.com/results?search_query=Chaiyya+Chaiyya+Sukhwinder+Singh+%26+Sapna+Awasthi+official+audio"],
["🎵","Vande Mataram","A.R. Rahman · Hindi","https://www.youtube.com/results?search_query=Vande+Mataram+A.R.+Rahman+official+audio"],
["🎵","Love You Zindagi","Jasleen Royal · Hindi","https://www.youtube.com/results?search_query=Love+You+Zindagi+Jasleen+Royal+official+audio"],
["🎵","Perfect","Ed Sheeran · English","https://www.youtube.com/results?search_query=Perfect+Ed+Sheeran+official+audio"],
["🎵","Photograph","Ed Sheeran · English","https://www.youtube.com/results?search_query=Photograph+Ed+Sheeran+official+audio"],
["🎵","Shape of You","Ed Sheeran · English","https://www.youtube.com/results?search_query=Shape+of+You+Ed+Sheeran+official+audio"],
["🎵","Count on Me","Bruno Mars · English","https://www.youtube.com/results?search_query=Count+on+Me+Bruno+Mars+official+audio"],
["🎵","A Sky Full of Stars","Coldplay · English","https://www.youtube.com/results?search_query=A+Sky+Full+of+Stars+Coldplay+official+audio"],
["🎵","Yellow","Coldplay · English","https://www.youtube.com/results?search_query=Yellow+Coldplay+official+audio"],
["🎵","Viva La Vida","Coldplay · English","https://www.youtube.com/results?search_query=Viva+La+Vida+Coldplay+official+audio"],
["🎵","Paradise","Coldplay · English","https://www.youtube.com/results?search_query=Paradise+Coldplay+official+audio"],
["🎵","Someone You Loved","Lewis Capaldi · English","https://www.youtube.com/results?search_query=Someone+You+Loved+Lewis+Capaldi+official+audio"],
["🎵","Before You Go","Lewis Capaldi · English","https://www.youtube.com/results?search_query=Before+You+Go+Lewis+Capaldi+official+audio"],
["🎵","See You Again","Wiz Khalifa ft. Charlie Puth · English","https://www.youtube.com/results?search_query=See+You+Again+Wiz+Khalifa+ft.+Charlie+Puth+official+audio"],
["🎵","A Thousand Years","Christina Perri · English","https://www.youtube.com/results?search_query=A+Thousand+Years+Christina+Perri+official+audio"],
["🎵","Let Her Go","Passenger · English","https://www.youtube.com/results?search_query=Let+Her+Go+Passenger+official+audio"],
["🎵","Photograph","Nickelback · English","https://www.youtube.com/results?search_query=Photograph+Nickelback+official+audio"],
["🎵","Hall of Fame","The Script · English","https://www.youtube.com/results?search_query=Hall+of+Fame+The+Script+official+audio"],
["🎵","Breakeven","The Script · English","https://www.youtube.com/results?search_query=Breakeven+The+Script+official+audio"],
["🎵","Counting Stars","OneRepublic · English","https://www.youtube.com/results?search_query=Counting+Stars+OneRepublic+official+audio"],
["🎵","I Lived","OneRepublic · English","https://www.youtube.com/results?search_query=I+Lived+OneRepublic+official+audio"],
["🎵","Demons","Imagine Dragons · English","https://www.youtube.com/results?search_query=Demons+Imagine+Dragons+official+audio"],
["🎵","On Top of the World","Imagine Dragons · English","https://www.youtube.com/results?search_query=On+Top+of+the+World+Imagine+Dragons+official+audio"],
["🎵","Believer","Imagine Dragons · English","https://www.youtube.com/results?search_query=Believer+Imagine+Dragons+official+audio"],
["🎵","Thunder","Imagine Dragons · English","https://www.youtube.com/results?search_query=Thunder+Imagine+Dragons+official+audio"],
["🎵","Memories","Maroon 5 · English","https://www.youtube.com/results?search_query=Memories+Maroon+5+official+audio"],
["🎵","Sugar","Maroon 5 · English","https://www.youtube.com/results?search_query=Sugar+Maroon+5+official+audio"],
["🎵","I'm Yours","Jason Mraz · English","https://www.youtube.com/results?search_query=I%27m+Yours+Jason+Mraz+official+audio"],
["🎵","Riptide","Vance Joy · English","https://www.youtube.com/results?search_query=Riptide+Vance+Joy+official+audio"],
["🎵","Take Me Home, Country Roads","John Denver · English","https://www.youtube.com/results?search_query=Take+Me+Home%2C+Country+Roads+John+Denver+official+audio"],
["🎵","Stand by Me","Ben E. King · English","https://www.youtube.com/results?search_query=Stand+by+Me+Ben+E.+King+official+audio"],
["🎵","Viva La Vida","Coldplay · English","https://www.youtube.com/results?search_query=Viva+La+Vida+Coldplay+official+audio"],
["🎵","The Nights","Avicii · English","https://www.youtube.com/results?search_query=The+Nights+Avicii+official+audio"]
    ],
    movies:{films:[
["🎬","The Lion King","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=The+Lion+King+movie+official+trailer"],
["🎬","Finding Nemo","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Finding+Nemo+movie+official+trailer"],
["🎬","Inside Out","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Inside+Out+movie+official+trailer"],
["🎬","Coco","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Coco+movie+official+trailer"],
["🎬","Toy Story","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Toy+Story+movie+official+trailer"],
["🎬","Up","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Up+movie+official+trailer"],
["🎬","WALL·E","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=WALL%C2%B7E+movie+official+trailer"],
["🎬","Spider-Man: Into the Spider-Verse","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Spider-Man%3A+Into+the+Spider-Verse+movie+official+trailer"],
["🎬","The Incredibles","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=The+Incredibles+movie+official+trailer"],
["🎬","Ratatouille","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Ratatouille+movie+official+trailer"],
["🎬","Harry Potter and the Philosopher's Stone","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Harry+Potter+and+the+Philosopher%27s+Stone+movie+official+trailer"],
["🎬","Harry Potter and the Prisoner of Azkaban","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Harry+Potter+and+the+Prisoner+of+Azkaban+movie+official+trailer"],
["🎬","The Lord of the Rings: The Fellowship of the Ring","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=The+Lord+of+the+Rings%3A+The+Fellowship+of+the+Ring+movie+official+trailer"],
["🎬","The Lord of the Rings: The Return of the King","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=The+Lord+of+the+Rings%3A+The+Return+of+the+King+movie+official+trailer"],
["🎬","The Chronicles of Narnia: The Lion, the Witch and the Wardrobe","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=The+Chronicles+of+Narnia%3A+The+Lion%2C+the+Witch+and+the+Wardrobe+movie+official+trailer"],
["🎬","How to Train Your Dragon","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=How+to+Train+Your+Dragon+movie+official+trailer"],
["🎬","Kung Fu Panda","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Kung+Fu+Panda+movie+official+trailer"],
["🎬","Puss in Boots: The Last Wish","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Puss+in+Boots%3A+The+Last+Wish+movie+official+trailer"],
["🎬","The Mitchells vs. the Machines","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=The+Mitchells+vs.+the+Machines+movie+official+trailer"],
["🎬","Klaus","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Klaus+movie+official+trailer"],
["🎬","Back to the Future","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Back+to+the+Future+movie+official+trailer"],
["🎬","The Karate Kid","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=The+Karate+Kid+movie+official+trailer"],
["🎬","The Pursuit of Happyness","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=The+Pursuit+of+Happyness+movie+official+trailer"],
["🎬","The Martian","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=The+Martian+movie+official+trailer"],
["🎬","Interstellar","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Interstellar+movie+official+trailer"],
["🎬","Inception","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Inception+movie+official+trailer"],
["🎬","The Truman Show","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=The+Truman+Show+movie+official+trailer"],
["🎬","Hidden Figures","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Hidden+Figures+movie+official+trailer"],
["🎬","October Sky","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=October+Sky+movie+official+trailer"],
["🎬","The Sound of Music","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=The+Sound+of+Music+movie+official+trailer"],
["🎬","3 Idiots","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=3+Idiots+movie+official+trailer"],
["🎬","Taare Zameen Par","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Taare+Zameen+Par+movie+official+trailer"],
["🎬","Dangal","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Dangal+movie+official+trailer"],
["🎬","Chhichhore","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Chhichhore+movie+official+trailer"],
["🎬","Zindagi Na Milegi Dobara","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Zindagi+Na+Milegi+Dobara+movie+official+trailer"],
["🎬","Bajrangi Bhaijaan","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Bajrangi+Bhaijaan+movie+official+trailer"],
["🎬","Secret Superstar","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Secret+Superstar+movie+official+trailer"],
["🎬","English Vinglish","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=English+Vinglish+movie+official+trailer"],
["🎬","PK","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=PK+movie+official+trailer"],
["🎬","Lagaan","Movie · বাছাই করা সিনেমা","https://www.google.com/search?q=Lagaan+movie+official+trailer"],
["🎬","Monpura","Movie · বাংলা","https://www.google.com/search?q=Monpura+movie+official+trailer"],
["🎬","Aynabaji","Movie · বাংলা","https://www.google.com/search?q=Aynabaji+movie+official+trailer"],
["🎬","Debi","Movie · বাংলা","https://www.google.com/search?q=Debi+movie+official+trailer"],
["🎬","Hawa","Movie · বাংলা","https://www.google.com/search?q=Hawa+movie+official+trailer"],
["🎬","Poran","Movie · বাংলা","https://www.google.com/search?q=Poran+movie+official+trailer"],
["🎬","The Secret Life of Walter Mitty","Movie · বাংলা","https://www.google.com/search?q=The+Secret+Life+of+Walter+Mitty+movie+official+trailer"],
["🎬","A Beautiful Mind","Movie · বাংলা","https://www.google.com/search?q=A+Beautiful+Mind+movie+official+trailer"],
["🎬","The Imitation Game","Movie · বাংলা","https://www.google.com/search?q=The+Imitation+Game+movie+official+trailer"],
["🎬","The Boy Who Harnessed the Wind","Movie · বাংলা","https://www.google.com/search?q=The+Boy+Who+Harnessed+the+Wind+movie+official+trailer"],
["🎬","The Fabelmans","Movie · বাংলা","https://www.google.com/search?q=The+Fabelmans+movie+official+trailer"]
    ],series:[
["📺","Planet Earth","Series · বাছাই করা","https://www.google.com/search?q=Planet+Earth+series+official+trailer"],
["📺","Our Planet","Series · বাছাই করা","https://www.google.com/search?q=Our+Planet+series+official+trailer"],
["📺","Blue Planet II","Series · বাছাই করা","https://www.google.com/search?q=Blue+Planet+II+series+official+trailer"],
["📺","Cosmos: A Spacetime Odyssey","Series · বাছাই করা","https://www.google.com/search?q=Cosmos%3A+A+Spacetime+Odyssey+series+official+trailer"],
["📺","Bluey","Series · বাছাই করা","https://www.google.com/search?q=Bluey+series+official+trailer"],
["📺","Avatar: The Last Airbender","Series · বাছাই করা","https://www.google.com/search?q=Avatar%3A+The+Last+Airbender+series+official+trailer"],
["📺","The Dragon Prince","Series · বাছাই করা","https://www.google.com/search?q=The+Dragon+Prince+series+official+trailer"],
["📺","Hilda","Series · বাছাই করা","https://www.google.com/search?q=Hilda+series+official+trailer"],
["📺","Gravity Falls","Series · বাছাই করা","https://www.google.com/search?q=Gravity+Falls+series+official+trailer"],
["📺","The Amazing World of Gumball","Series · বাছাই করা","https://www.google.com/search?q=The+Amazing+World+of+Gumball+series+official+trailer"],
["📺","Stranger Things","Series · বাছাই করা","https://www.google.com/search?q=Stranger+Things+series+official+trailer"],
["📺","Wednesday","Series · বাছাই করা","https://www.google.com/search?q=Wednesday+series+official+trailer"],
["📺","A Series of Unfortunate Events","Series · বাছাই করা","https://www.google.com/search?q=A+Series+of+Unfortunate+Events+series+official+trailer"],
["📺","Anne with an E","Series · বাছাই করা","https://www.google.com/search?q=Anne+with+an+E+series+official+trailer"],
["📺","The Good Place","Series · বাছাই করা","https://www.google.com/search?q=The+Good+Place+series+official+trailer"],
["📺","Young Sheldon","Series · বাছাই করা","https://www.google.com/search?q=Young+Sheldon+series+official+trailer"],
["📺","The Big Bang Theory","Series · বাছাই করা","https://www.google.com/search?q=The+Big+Bang+Theory+series+official+trailer"],
["📺","Sherlock","Series · বাছাই করা","https://www.google.com/search?q=Sherlock+series+official+trailer"],
["📺","Doctor Who","Series · বাছাই করা","https://www.google.com/search?q=Doctor+Who+series+official+trailer"],
["📺","Lost in Space","Series · বাছাই করা","https://www.google.com/search?q=Lost+in+Space+series+official+trailer"],
["📺","The Mandalorian","Series · বাছাই করা","https://www.google.com/search?q=The+Mandalorian+series+official+trailer"],
["📺","Andor","Series · বাছাই করা","https://www.google.com/search?q=Andor+series+official+trailer"],
["📺","Loki","Series · বাছাই করা","https://www.google.com/search?q=Loki+series+official+trailer"],
["📺","WandaVision","Series · বাছাই করা","https://www.google.com/search?q=WandaVision+series+official+trailer"],
["📺","The Falcon and the Winter Soldier","Series · বাছাই করা","https://www.google.com/search?q=The+Falcon+and+the+Winter+Soldier+series+official+trailer"],
["📺","The Queen's Gambit","Series · বাছাই করা","https://www.google.com/search?q=The+Queen%27s+Gambit+series+official+trailer"],
["📺","Atypical","Series · বাছাই করা","https://www.google.com/search?q=Atypical+series+official+trailer"],
["📺","Heartstopper","Series · বাছাই করা","https://www.google.com/search?q=Heartstopper+series+official+trailer"],
["📺","One Piece","Series · বাছাই করা","https://www.google.com/search?q=One+Piece+series+official+trailer"],
["📺","Avatar: The Legend of Korra","Series · বাছাই করা","https://www.google.com/search?q=Avatar%3A+The+Legend+of+Korra+series+official+trailer"],
["📺","The Office (US)","Series · বাছাই করা","https://www.google.com/search?q=The+Office+%28US%29+series+official+trailer"],
["📺","Brooklyn Nine-Nine","Series · বাছাই করা","https://www.google.com/search?q=Brooklyn+Nine-Nine+series+official+trailer"],
["📺","Modern Family","Series · বাছাই করা","https://www.google.com/search?q=Modern+Family+series+official+trailer"],
["📺","Parks and Recreation","Series · বাছাই করা","https://www.google.com/search?q=Parks+and+Recreation+series+official+trailer"],
["📺","Ted Lasso","Series · বাছাই করা","https://www.google.com/search?q=Ted+Lasso+series+official+trailer"],
["📺","The Railway Men","Series · বাছাই করা","https://www.google.com/search?q=The+Railway+Men+series+official+trailer"],
["📺","Panchayat","Series · বাছাই করা","https://www.google.com/search?q=Panchayat+series+official+trailer"],
["📺","Kota Factory","Series · বাছাই করা","https://www.google.com/search?q=Kota+Factory+series+official+trailer"],
["📺","Aspirants","Series · বাছাই করা","https://www.google.com/search?q=Aspirants+series+official+trailer"],
["📺","Gullak","Series · বাছাই করা","https://www.google.com/search?q=Gullak+series+official+trailer"],
["📺","Mohanagar","Series · বাছাই করা","https://www.google.com/search?q=Mohanagar+series+official+trailer"],
["📺","Karagar","Series · বাছাই করা","https://www.google.com/search?q=Karagar+series+official+trailer"],
["📺","Taqdeer","Series · বাছাই করা","https://www.google.com/search?q=Taqdeer+series+official+trailer"],
["📺","Sabrina","Series · বাছাই করা","https://www.google.com/search?q=Sabrina+series+official+trailer"],
["📺","Kaiser","Series · বাছাই করা","https://www.google.com/search?q=Kaiser+series+official+trailer"],
["📺","The Good Doctor","Series · বাছাই করা","https://www.google.com/search?q=The+Good+Doctor+series+official+trailer"],
["📺","The Mysterious Benedict Society","Series · বাছাই করা","https://www.google.com/search?q=The+Mysterious+Benedict+Society+series+official+trailer"],
["📺","Lost","Series · বাছাই করা","https://www.google.com/search?q=Lost+series+official+trailer"],
["📺","The Story of God with Morgan Freeman","Series · বাছাই করা","https://www.google.com/search?q=The+Story+of+God+with+Morgan+Freeman+series+official+trailer"],
["📺","The Blue Planet","Series · বাছাই করা","https://www.google.com/search?q=The+Blue+Planet+series+official+trailer"]
    ]},
    tech:[['🤖','AI & Technology','AI, নতুন প্রযুক্তি ও উদ্ভাবন','https://www.google.com/search?q=latest+technology+explained'],['📱','Apps','দরকারি অ্যাপ ও টুল','https://www.google.com/search?q=useful+free+apps'],['🔬','Science','বিজ্ঞান ও মহাকাশ','https://www.google.com/search?q=science+space+discoveries'],['💻','Coding','কোডিং শেখার রিসোর্স','https://developer.mozilla.org/']]
  };
  const exploreNames={gaming:'Gaming picks',music:'Music & playlists',movies:'Movies & series',tech:'Technology & ideas'};
  let mediaKind='films';
  function renderCards(rows,query=''){
    const host=$('#explore-content');
    const filtered=rows.filter(x=>x.slice(1,3).join(' ').toLowerCase().includes(query.toLowerCase()));
    host.innerHTML=filtered.length?filtered.map(x=>`<article class="discover-card"><span class="discover-emoji">${x[0]}</span><h4>${safeText(x[1])}</h4><p>${safeText(x[2])}</p><a href="${x[3]}" target="_blank" rel="noopener noreferrer">খুঁজে দেখো ↗</a></article>`).join(''):'<p class="muted">কোনো ফল পাওয়া যায়নি। অন্য শব্দ দিয়ে খুঁজে দেখো।</p>';
  }
  function renderExplore(kind='gaming',query=''){
    const host=$('#explore-content');if(!host)return;
    $('#explore-title').textContent=exploreNames[kind];
    if(kind==='movies'){
      const rows=exploreData.movies[mediaKind].filter(x=>x.slice(1,3).join(' ').toLowerCase().includes(query.toLowerCase()));
      host.innerHTML=`<div class="media-subtabs"><button class="explore-tab ${mediaKind==='films'?'active':''}" data-media-list="films">🎬 ৫০টি Movie</button><button class="explore-tab ${mediaKind==='series'?'active':''}" data-media-list="series">📺 ৫০টি Series</button></div><p class="catalog-count">${mediaKind==='films'?'৫০টি বাছাই করা সিনেমা':'৫০টি বাছাই করা সিরিজ'}</p><div class="discover-grid-inner">${rows.length?rows.map(x=>`<article class="discover-card"><span class="discover-emoji">${x[0]}</span><h4>${safeText(x[1])}</h4><p>${safeText(x[2])}</p><a href="${x[3]}" target="_blank" rel="noopener noreferrer">ট্রেলার / তথ্য ↗</a></article>`).join(''):'<p class="muted">কোনো ফল পাওয়া যায়নি।</p>'}</div>`;
    }else renderCards(exploreData[kind],query);
  }
  $('#page-explore')?.addEventListener('click',e=>{
    const media=e.target.closest('[data-media-list]');
    if(media){mediaKind=media.dataset.mediaList;renderExplore('movies',$('#explore-search').value);}
  });
  let exploreKind='gaming';
  $$('#page-explore [data-explore]').forEach(b=>b.addEventListener('click',()=>{exploreKind=b.dataset.explore;$$('#page-explore [data-explore]').forEach(x=>x.classList.toggle('active',x===b));renderExplore(exploreKind,$('#explore-search').value);}));
  $('#explore-search')?.addEventListener('input',e=>renderExplore(exploreKind,e.target.value));renderExplore();
  renderPosts();renderProfile();
  if('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./sw.js').catch(()=>{});
})();