(() => {
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const store = {
    get(key, fallback) { try { const v=localStorage.getItem('myspace_'+key); return v ? JSON.parse(v) : fallback; } catch { return fallback; } },
    set(key, value) { try { localStorage.setItem('myspace_'+key, JSON.stringify(value)); } catch {} },
    del(key) { try { localStorage.removeItem('myspace_'+key); } catch {} }
  };
  let posts = store.get('posts', []);
  let saved = store.get('saved', []);
  let profile = store.get('profile', {name:'My Profile', bio:'Your story starts here.'});
  let votes = store.get('votes', {});
  const pageNames = {home:'Home',profile:'My Profile',explore:'Explore',messages:'Messages',wafi:'WaFi AI',fun:'Fun Zone',friends:'Friends',gallery:'Gallery & Memories',notifications:'Notifications',settings:'Settings',create:'Create Post',polls:'Polls & Surveys',vibes:'My Vibes',saved:'Saved Items',privacy:'Privacy & Security'};
  function showPage(name) {
    if (!pageNames[name]) name='home';
    $$('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+name));
    $$('[data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page===name));
    $('#page-heading').textContent=pageNames[name];
    window.scrollTo({top:0,behavior:'smooth'});
    if(name==='saved') renderSaved();
    if(name==='profile') renderProfile();
  }
  document.addEventListener('click', e=>{
    const nav=e.target.closest('[data-page]');
    if(nav){e.preventDefault();showPage(nav.dataset.page);}
  });
  const themeSelect=$('#theme-select'), themeToggle=$('#theme-toggle');
  function setTheme(v){document.body.classList.toggle('light',v==='light'); if(themeSelect)themeSelect.value=v;store.set('theme',v);}
  setTheme(store.get('theme','dark'));
  themeSelect?.addEventListener('change',e=>setTheme(e.target.value==='system'?(matchMedia('(prefers-color-scheme: light)').matches?'light':'dark'):e.target.value));
  themeToggle?.addEventListener('click',()=>setTheme(document.body.classList.contains('light')?'dark':'light'));

  function safeText(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function postCard(post, withSave=true){
    const isSaved=saved.some(x=>x.id===post.id);
    return `<article class="post-card"><div class="post-meta"><strong>${safeText(post.author||profile.name)}</strong><time>${new Date(post.time).toLocaleString()}</time></div><p>${safeText(post.text)}</p><div class="post-actions">${withSave?`<button data-save="${post.id}">${isSaved?'★ Saved':'☆ Save'}</button>`:''}<span>Local demo post</span></div></article>`;
  }
  function renderPosts(){
    const feed=$('#feed-posts'); if(feed)feed.innerHTML=posts.length?posts.slice().reverse().map(p=>postCard(p)).join(''):'<p class="muted">এখনো কোনো পোস্ট নেই।</p>';
    const profileFeed=$('#profile-posts'); if(profileFeed)profileFeed.innerHTML=posts.length?posts.slice().reverse().map(p=>postCard(p)).join(''):'<p class="muted">তোমার প্রথম পোস্টটি তৈরি করো।</p>';
    const count=$('#post-count'); if(count)count.textContent=posts.length;
  }
  document.addEventListener('myspace:profile-loaded',e=>{
    const d=e.detail||{};profile={name:String(d.display_name||'My Space User'),bio:String(d.bio||'')};store.set('profile',profile);renderProfile();
  });
  function renderProfile(){
    $('#profile-name').textContent=profile.name;
    $('#profile-handle').textContent='@'+profile.name.toLowerCase().replace(/[^a-z0-9]+/g,'')+' · Your personal space';
    $('#profile-bio').textContent=profile.bio;
    $('#profile-avatar').textContent=(profile.name.trim()[0]||'M').toUpperCase();
    renderPosts();
  }
  $('#edit-profile')?.addEventListener('click',()=>{
    const name=prompt('তোমার Profile Name লিখো:',profile.name); if(name===null)return;
    const bio=prompt('এক লাইনের Bio লিখো:',profile.bio); if(bio===null)return;
    profile={name:name.trim().slice(0,32)||'My Profile',bio:bio.trim().slice(0,160)||'Your story starts here.'};
    store.set('profile',profile);renderProfile();
  });
  const postText=$('#post-text'), charCount=$('#char-count');
  postText?.addEventListener('input',()=>charCount.textContent=`${postText.value.length} / 1000`);
  $('#publish-post')?.addEventListener('click',()=>{
    const text=postText.value.trim(); if(!text){alert('আগে কিছু লিখো।');return;}
    posts.push({id:Date.now().toString(),text,author:profile.name,time:new Date().toISOString()});
    store.set('posts',posts);postText.value='';charCount.textContent='0 / 1000';renderPosts();showPage('create');
  });
  document.addEventListener('click',e=>{
    const b=e.target.closest('[data-save]');if(!b)return;
    const post=posts.find(p=>p.id===b.dataset.save);if(!post)return;
    if(saved.some(p=>p.id===post.id))saved=saved.filter(p=>p.id!==post.id);else saved.push(post);
    store.set('saved',saved);renderPosts();renderSaved();
  });
  function renderSaved(){const el=$('#saved-list');if(el)el.innerHTML=saved.length?saved.slice().reverse().map(p=>postCard(p,false)).join(''):'<div class="empty-state"><span>▣</span><h3>কিছু সংরক্ষণ করা হয়নি</h3><p>পোস্ট থেকে ☆ Save চাপলে এখানে দেখা যাবে।</p></div>';}
  $('#poll-options')?.addEventListener('click',e=>{
    const b=e.target.closest('[data-vote]');if(!b)return;
    votes.today=b.dataset.vote;store.set('votes',votes);
    $('#poll-result').textContent='তোমার ভোট: '+votes.today+' — ডেমো ভোট শুধু এই ডিভাইসে থাকে।';
    $$('#poll-options button').forEach(x=>x.classList.toggle('chosen',x===b));
  });
  if(votes.today){$('#poll-result').textContent='তোমার ভোট: '+votes.today+' — ডেমো ভোট শুধু এই ডিভাইসে থাকে।';$$('#poll-options button').forEach(x=>x.classList.toggle('chosen',x.dataset.vote===votes.today));}
  $('#create-poll')?.addEventListener('click',async()=>{
    const q=$('#poll-question').value.trim(),a=$('#poll-choice1').value.trim(),b=$('#poll-choice2').value.trim();
    if(!q||!a||!b){$('#poll-created').textContent='প্রশ্ন ও দুটি অপশন পূরণ করো।';return;}
    try {
      if(window.mySpaceSupabaseClient && window.MySpaceCloudFeatures){
        const {data:{user}}=await window.mySpaceSupabaseClient.auth.getUser();
        if(user){await window.MySpaceCloudFeatures.createPoll(q,[a,b]);$('#poll-created').textContent='Community poll তৈরি হয়েছে।';document.dispatchEvent(new CustomEvent('myspace:polls-refresh'));}
        else $('#poll-created').textContent=`ডেমো পোল: ${q} (${a} / ${b}) — Sign in করলে Community-তে প্রকাশ করতে পারবে।`;
      } else $('#poll-created').textContent=`ডেমো পোল: ${q} (${a} / ${b})`;
    } catch(e){$('#poll-created').textContent=e.message||'Poll তৈরি করা যায়নি।';return;}
    $('#poll-question').value=$('#poll-choice1').value=$('#poll-choice2').value='';
  });
  $('#save-vibes')?.addEventListener('click',()=>{
    const data={};$$('.vibe-input').forEach(i=>data[i.dataset.vibe]=i.value.trim());store.set('vibes',data);$('#vibe-status').textContent='এই ডিভাইসে সেভ হয়েছে।';
  });
  const vibes=store.get('vibes',{});$$('.vibe-input').forEach(i=>i.value=vibes[i.dataset.vibe]||'');
  $('#clear-local')?.addEventListener('click',()=>{
    if(!confirm('এই ডিভাইসের My Space ডেমো পোস্ট, প্রোফাইল, পোল ও পছন্দ মুছবে। নিশ্চিত?'))return;
    ['posts','saved','profile','votes','vibes'].forEach(store.del);posts=[];saved=[];profile={name:'My Profile',bio:'Your story starts here.'};votes={};renderPosts();renderProfile();renderSaved();$('#clear-status').textContent='ডেমো ডেটা মুছে ফেলা হয়েছে।';
  });

  // WaFi offline preview: transparent, rule-based sample replies; no external AI connection.
  const chat=$('#page-wafi');
  if(chat){
    const box=$('.chat-disabled',chat);
    if(box){box.className='chat-input-row';box.innerHTML='<input id="wafi-input" aria-label="Message WaFi" placeholder="WaFi-কে কিছু জিজ্ঞেস করো..."><button id="wafi-send">Send</button>';}
    const suggestions=$('.suggestions',chat);
    suggestions?.addEventListener('click',e=>{const b=e.target.closest('button');if(b)sendWaFi(b.textContent);});
    $('#wafi-send')?.addEventListener('click',()=>sendWaFi($('#wafi-input').value));
    $('#wafi-input')?.addEventListener('keydown',e=>{if(e.key==='Enter')sendWaFi(e.target.value);});
    function sendWaFi(value){
      const v=String(value||'').trim();if(!v)return;
      let answer='আমি এখন My Space-এর অফলাইন প্রিভিউ মোডে আছি। বাস্তব AI উত্তর পেতে নিরাপদ Backend ও AI API সংযোগ করতে হবে।';
      if(/caption|ক্যাপশন/i.test(v))answer='ক্যাপশন আইডিয়া: “ছোট ছোট মুহূর্তেই তৈরি হয় সুন্দর স্মৃতি।” চাইলে পোস্টের বিষয় বলো, আমি আরও আইডিয়া সাজিয়ে দিতে পারি।';
      else if(/quiz|কুইজ/i.test(v))answer='মিনি কুইজ: বাংলাদেশের জাতীয় ফুল কোনটি? ক) গোলাপ খ) শাপলা গ) জুঁই — উত্তর: খ) শাপলা।';
      else if(/idea|আইডিয়া/i.test(v))answer='আইডিয়া: My Space-এ “আজকের প্রশ্ন” নামে একটি দৈনিক কমিউনিটি প্রশ্ন চালু করতে পারো।';
      const area=$('.wafi-chat',chat);let log=$('#wafi-log');if(!log){log=document.createElement('div');log.id='wafi-log';log.className='chat-log';area.appendChild(log);}
      log.insertAdjacentHTML('beforeend',`<div class="chat-bubble user">${safeText(v)}</div><div class="chat-bubble bot">${safeText(answer)}</div>`);
      $('#wafi-input').value='';
    }
  }
  // Tic-tac-toe playable local game in Fun Zone.
  const fun=$('#page-fun');
  if(fun){
    const grid=document.createElement('div');grid.className='panel game-panel';grid.innerHTML='<h3>Tic Tac Toe</h3><div id="ttt-board" class="ttt-board">'+Array.from({length:9},(_,i)=>`<button data-cell="${i}" aria-label="Cell ${i+1}"></button>`).join('')+'</div><p id="ttt-status">তোমার চাল: X</p><button id="ttt-reset" class="secondary-btn">নতুন গেম</button>';
    fun.appendChild(grid);let cells=Array(9).fill(''),turn='X',done=false;
    const wins=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
    function reset(){cells=Array(9).fill('');turn='X';done=false;$$('[data-cell]',grid).forEach(b=>b.textContent='');$('#ttt-status',grid).textContent='তোমার চাল: X';}
    grid.addEventListener('click',e=>{
      const b=e.target.closest('[data-cell]');if(!b||done||cells[+b.dataset.cell])return;
      const i=+b.dataset.cell;cells[i]=turn;b.textContent=turn;
      if(wins.some(w=>w.every(n=>cells[n]===turn))){$('#ttt-status',grid).textContent=turn+' জিতেছে!';done=true;return;}
      if(cells.every(Boolean)){$('#ttt-status',grid).textContent='ড্র হয়েছে!';done=true;return;}
      turn=turn==='X'?'O':'X';$('#ttt-status',grid).textContent='পরের চাল: '+turn;
    });
    $('#ttt-reset',grid).addEventListener('click',reset);
  }
  renderPosts();renderProfile();
  if('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./sw.js').catch(()=>{});
})();