(() => {
  const cfg=window.MY_SPACE_SUPABASE_CONFIG||{};
  const overlay=document.getElementById('auth-overlay');
  const status=document.getElementById('auth-status');
  const openBtn=document.getElementById('auth-open');
  const closeBtn=document.getElementById('auth-close');
  const signIn=document.getElementById('auth-signin');
  const signUp=document.getElementById('auth-signup');
  const signOut=document.getElementById('auth-signout');
  const emailEl=document.getElementById('auth-email');
  const passEl=document.getElementById('auth-password');
  let client=null, currentUser=null;
  const configured=cfg.url && !cfg.url.includes('YOUR_PROJECT') && cfg.anonKey && !cfg.anonKey.includes('YOUR_');
  function message(text,type=''){if(status){status.textContent=text;status.className='auth-status '+type;}}
  function show(){overlay.hidden=false;}
  function hide(){overlay.hidden=true;}
  openBtn?.addEventListener('click',show);closeBtn?.addEventListener('click',hide);
  overlay?.addEventListener('click',e=>{if(e.target===overlay)hide();});
  if(!configured){message('Offline demo mode: supabase-config.js-এ Supabase Project URL ও anon public key বসালে Auth চালু হবে।');return;}
  if(!window.supabase?.createClient){message('Supabase SDK লোড হয়নি। ইন্টারনেট সংযোগ পরীক্ষা করো।','error');return;}
  client=window.supabase.createClient(cfg.url,cfg.anonKey,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
  window.mySpaceSupabaseClient=client;
  // Stable alias used by the social helper modules.
  window.mySpaceSupabase=client;
  async function ensureProfile(user){
    const meta=user.user_metadata||{};
    const uname=(meta.username||('user_'+user.id.replace(/-/g,'').slice(0,12))).toLowerCase().replace(/[^a-z0-9_]/g,'').slice(0,24);
    const {error}=await client.from('profiles').upsert({id:user.id,username:uname,display_name:meta.display_name||'My Space User'},{onConflict:'id',ignoreDuplicates:true});
    if(error)throw error;
  }
  async function refreshSession(){
    const {data,error}=await client.auth.getSession();if(error)throw error;
    currentUser=data.session?.user||null;
    openBtn.textContent=currentUser?'Account':'Sign in';
    signOut.hidden=!currentUser;
    if(currentUser){await ensureProfile(currentUser);const {data:profile,error:profileError}=await client.from('profiles').select('display_name,bio').eq('id',currentUser.id).single();if(!profileError&&profile)document.dispatchEvent(new CustomEvent('myspace:profile-loaded',{detail:profile}));message('Signed in: '+currentUser.email,'ok');await loadCloudPosts();}
    else message('তুমি এখনো Sign in করোনি।');
  }
  signIn?.addEventListener('click',async()=>{
    const email=emailEl.value.trim(),password=passEl.value;
    if(!email||password.length<8){message('সঠিক Email ও কমপক্ষে ৮ অক্ষরের Password দাও।','error');return;}
    signIn.disabled=true;
    const {error}=await client.auth.signInWithPassword({email,password});
    signIn.disabled=false;
    if(error){message(error.message,'error');return;}
    await refreshSession();
  });
  signUp?.addEventListener('click',async()=>{
    const email=emailEl.value.trim(),password=passEl.value;
    if(!email||password.length<8){message('সঠিক Email ও কমপক্ষে ৮ অক্ষরের Password দাও।','error');return;}
    signUp.disabled=true;
    const {data,error}=await client.auth.signUp({email,password});
    signUp.disabled=false;
    if(error){message(error.message,'error');return;}
    if(data.user&&!data.session)message('Confirmation email পাঠানো হয়েছে। Email verify করে তারপর Sign in করো।','ok');
    else {await refreshSession();}
  });
  signOut?.addEventListener('click',async()=>{
    const {error}=await client.auth.signOut();if(error){message(error.message,'error');return;}
    currentUser=null;openBtn.textContent='Sign in';signOut.hidden=true;message('Sign out সম্পন্ন হয়েছে।','ok');
  });
  async function loadCloudPosts(){
    if(!currentUser)return;
    const {data,error}=await client.from('posts').select('id,body,created_at,profiles(display_name,username)').order('created_at',{ascending:false}).limit(20);
    if(error){message('Cloud posts load হয়নি: '+error.message,'error');return;}
    const host=document.getElementById('feed-posts');if(!host||!data?.length)return;
    const existing=new Set([...host.querySelectorAll('[data-cloud-post]')].map(x=>x.dataset.cloudPost));
    data.forEach(post=>{
      if(existing.has(post.id))return;
      const article=document.createElement('article');article.className='post-card';article.dataset.cloudPost=post.id;
      const meta=document.createElement('div');meta.className='post-meta';
      const who=document.createElement('strong');who.textContent=post.profiles?.display_name||post.profiles?.username||'My Space User';
      const time=document.createElement('time');time.textContent=new Date(post.created_at).toLocaleString();
      meta.append(who,time);
      const body=document.createElement('p');body.textContent=post.body;
      const foot=document.createElement('div');foot.className='post-actions';foot.textContent='Cloud post';
      article.append(meta,body,foot);host.prepend(article);
    });
  }
  // The Phase 2 composer still saves locally. When signed in, mirror the newly-created
  // post to Supabase; local-only behavior remains if no connection is configured.
  let lastPostId=null;
  document.getElementById('publish-post')?.addEventListener('click',()=>{
    if(!currentUser)return;
    setTimeout(async()=>{
      try{
        const raw=localStorage.getItem('myspace_posts');const list=raw?JSON.parse(raw):[];
        const post=list[list.length-1];if(!post||post.id===lastPostId)return;lastPostId=post.id;
        const {error}=await client.from('posts').insert({user_id:currentUser.id,body:post.text,visibility:'public'});
        if(error)message('Post local-এ আছে, কিন্তু cloud-এ যায়নি: '+error.message,'error');
        else {message('Post cloud-এ publish হয়েছে।','ok');await loadCloudPosts();}
      }catch(e){message('Cloud sync error: '+e.message,'error');}
    },150);
  });
  client.auth.onAuthStateChange((_event,session)=>{
    currentUser=session?.user||null;
    openBtn.textContent=currentUser?'Account':'Sign in';
    signOut.hidden=!currentUser;
    if(!currentUser){
      const feed=document.getElementById('feed-posts');
      if(feed) feed.querySelectorAll('[data-cloud-post]').forEach(x=>x.remove());
    }
  });
  refreshSession().catch(e=>message('Auth setup error: '+e.message,'error'));
  window.MySpaceCloud={get client(){return client;},get user(){return currentUser;},reloadPosts:loadCloudPosts};
})();