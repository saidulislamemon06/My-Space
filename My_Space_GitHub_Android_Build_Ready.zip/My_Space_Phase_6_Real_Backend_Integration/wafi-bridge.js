/* WaFi real AI client. Requires configured Supabase + deployed wafi-chat Edge Function. */
(() => {
  const cfg=window.MY_SPACE_SUPABASE_CONFIG||{};
  const ready=()=>window.mySpaceSupabaseClient||null;
  function client(){const c=ready();if(!c)throw new Error('আগে Supabase sign-in ও configuration সম্পন্ন করো।');return c;}
  async function ask(message){const sb=client();const {data:{session}}=await sb.auth.getSession();if(!session)throw new Error('WaFi ব্যবহার করতে Sign in করো।');
    const {data,error}=await sb.functions.invoke('wafi-chat',{body:{message:String(message||'').trim()}});if(error)throw error;if(data?.error)throw new Error(data.error);return data.reply;}
  async function listApprovedMemory(){const sb=client();const {data,error}=await sb.from('wafi_memory').select('id,memory_text,created_at').eq('user_approved',true).order('created_at',{ascending:false});if(error)throw error;return data||[];}
  async function addApprovedMemory(memoryText){const sb=client();const {data:{user}}=await sb.auth.getUser();if(!user)throw new Error('Sign in required');const value=String(memoryText||'').trim();if(!value||value.length>500)throw new Error('স্মৃতি ১–৫০০ অক্ষরের মধ্যে হতে হবে।');const {data,error}=await sb.from('wafi_memory').insert({user_id:user.id,memory_text:value,user_approved:true}).select().single();if(error)throw error;return data;}
  async function removeMemory(id){const {error}=await client().from('wafi_memory').delete().eq('id',id);if(error)throw error;}
  window.MySpaceWaFi={ask,listApprovedMemory,addApprovedMemory,removeMemory};
})();
