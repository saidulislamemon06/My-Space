# Android প্রস্তুতি (Phase 9)

এই সোর্স Capacitor wrapper-এর জন্য প্রস্তুত; এটি APK/AAB নয় এবং Android Studio build/sign না করা পর্যন্ত installable app নয়।

## Build steps
1. Node.js LTS, Android Studio, Android SDK এবং JDK 17 ইনস্টল করো।
2. এই ফোল্ডারে `npm install` চালাও।
3. Supabase Project URL ও anon/public key `supabase-config.js`-এ বসাও। এখানে কখনো service-role বা AI provider secret বসাবে না।
4. `npx cap add android` (শুধু প্রথমবার), এরপর `npx cap sync android`।
5. `npx cap open android` দিয়ে Android Studio খুলে Gradle sync করো।
6. Emulator/নিজের test device-এ debug build চালাও। Production-এর জন্য signed Android App Bundle (AAB), Play App Signing, privacy disclosures ও Data safety form সম্পন্ন করতে হবে।

## Native permission policy
Gallery upload-এর জন্য Android Photo Picker ব্যবহার করবে; অপ্রয়োজনীয় broad storage permission যোগ করবে না। Camera/microphone permission কেবল feature ব্যবহারকারী স্পষ্টভাবে চালু করলে চাইবে। Push notification-এর জন্য FCM/APNs credentials, device token registration এবং notification permission আলাদাভাবে configure করতে হবে।

## গুরুত্বপূর্ণ সীমা
- PWA installability ও offline shell প্রস্তুত; authenticated content/API offline cache হয় না।
- এই প্যাকেজে Android project/keystore/Play Store submission নেই। Build environment এবং signing credentials ছাড়া APK/AAB তৈরি হয়েছে বলা যাবে না।
- Supabase-এ HTTPS domain, redirect URLs, SMTP/email confirmation, secrets, database migrations, cron cleanup ও backups configure করতে হবে।
