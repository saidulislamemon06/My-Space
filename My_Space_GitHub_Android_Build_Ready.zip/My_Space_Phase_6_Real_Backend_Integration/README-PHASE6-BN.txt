MY SPACE — PHASE 6 REAL BACKEND INTEGRATION

Phase 1–5 package থেকে Phase 5-এর exact source base ব্যবহার করা হয়েছে। নতুন backend integration আলাদা file/migration-এ যোগ হয়েছে।

নতুন:
- WaFi AI Edge Function (approved-memory-only, moderation, rate limit)
- Private Gallery/Storage bridge + media-access signed URL Edge Function
- Stories + Reels schema/RLS
- Notifications table + DB triggers
- Friends/Messages/Block/Report extended client API
- Admin actions Edge Function, moderation RPC, audit log
- Bangla setup + test plan

কোনো secret frontend-এ নেই। এই ZIP deploy না করা পর্যন্ত feature Live নয়। আগে docs/PHASE6_SETUP_BN.md পড়ো।
