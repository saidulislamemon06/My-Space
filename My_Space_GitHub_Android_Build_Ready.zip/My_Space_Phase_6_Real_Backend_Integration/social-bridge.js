/* My Space Phase 5: client-side social helpers.
 * Requires supabase-bridge.js to expose window.mySpaceSupabase.
 * These helpers rely on database RLS; never place service-role/API secrets here.
 */
(() => {
  "use strict";
  const client = () => window.mySpaceSupabase || null;
  const currentUser = async () => {
    const sb = client();
    if (!sb) throw new Error("Supabase এখনো কনফিগার করা হয়নি।");
    const { data, error } = await sb.auth.getUser();
    if (error) throw error;
    if (!data.user) throw new Error("আগে Sign in করো।");
    return data.user;
  };

  async function sendFriendRequest(addresseeId) {
    const sb = client(), user = await currentUser();
    if (!addresseeId || addresseeId === user.id) throw new Error("এই friend request পাঠানো যাবে না।");
    const { data: blocked } = await sb.from("user_blocks").select("blocked_id")
      .eq("blocker_id", addresseeId).eq("blocked_id", user.id).maybeSingle();
    if (blocked) throw new Error("এই ব্যবহারকারী তোমাকে block করেছে।");
    const { data, error } = await sb.from("friendships")
      .insert({ requester_id: user.id, addressee_id: addresseeId, status: "pending" })
      .select().single();
    if (error) throw error;
    return data;
  }

  async function decideFriendRequest(requestId, decision) {
    const sb = client(); await currentUser();
    if (!["accepted", "declined"].includes(decision)) throw new Error("অবৈধ সিদ্ধান্ত।");
    const { data, error } = await sb.from("friendships")
      .update({ status: decision }).eq("id", requestId).eq("status", "pending")
      .select().single();
    if (error) throw error;
    return data;
  }

  async function listFriends() {
    const sb = client(), user = await currentUser();
    const { data, error } = await sb.from("friendships").select("*").eq("status", "accepted")
      .or(`requester_id.eq.${user.id},addressee_id.eq.${user.id}`);
    if (error) throw error;
    return data || [];
  }

  async function sendMessage(recipientId, body) {
    const sb = client(), user = await currentUser();
    const clean = String(body || "").trim();
    if (!recipientId || recipientId === user.id || !clean || clean.length > 5000)
      throw new Error("মেসেজের তথ্য সঠিক নয়।");
    const { data, error } = await sb.from("messages")
      .insert({ sender_id: user.id, recipient_id: recipientId, body: clean })
      .select().single();
    if (error) throw error;
    return data;
  }

  async function loadConversation(otherUserId, limit = 40) {
    const sb = client(), user = await currentUser();
    const safeLimit = Math.max(1, Math.min(Number(limit) || 40, 100));
    const { data, error } = await sb.from("messages").select("*")
      .or(`and(sender_id.eq.${user.id},recipient_id.eq.${otherUserId}),and(sender_id.eq.${otherUserId},recipient_id.eq.${user.id})`)
      .order("created_at", { ascending: false }).limit(safeLimit);
    if (error) throw error;
    return (data || []).reverse();
  }

  async function markMessageRead(messageId) {
    const sb = client(); await currentUser();
    const { error } = await sb.from("messages").update({ read_at: new Date().toISOString() })
      .eq("id", messageId).is("read_at", null);
    if (error) throw error;
  }

  async function blockUser(userId) {
    const sb = client(), user = await currentUser();
    if (!userId || userId === user.id) throw new Error("নিজেকে block করা যাবে না।");
    const { error } = await sb.from("user_blocks").upsert(
      { blocker_id: user.id, blocked_id: userId }, { onConflict: "blocker_id,blocked_id" });
    if (error) throw error;
  }

  window.MySpaceSocial = {
    sendFriendRequest, decideFriendRequest, listFriends,
    sendMessage, loadConversation, markMessageRead, blockUser
  };
})();
