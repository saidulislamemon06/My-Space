MY SPACE — PHASE 2 INTERACTIVE FRONTEND
=======================================

কী আছে
- Responsive Home, Profile, Explore, Messages, WaFi, Fun Zone
- Create Post: পোস্ট তৈরি ও লোকালি সংরক্ষণ
- Polls: লোকাল ডেমো ভোট ও পোল তৈরির UI
- My Vibes: পছন্দের বিষয় লোকালি সংরক্ষণ
- Saved Items: পোস্ট বুকমার্ক
- Privacy & Security: নিরাপত্তা নীতির পরিচিতি ও ডেমো ডেটা মুছুন
- Tic Tac Toe: খেলার মতো লোকাল গেম
- Dark/Light theme preference
- Mobile navigation এবং PWA files

চালানোর নিয়ম (Android)
1. ZIP Extract করো।
2. Acode-এ Extract করা My_Space_Phase_2 ফোল্ডার Open Folder করো।
3. index.html খোলো।
4. Preview/Play চাপো।
5. CSS না এলে নিশ্চিত করো index.html, styles.css, app.js একই ফোল্ডারে আছে।

গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি এখনও Frontend Prototype; পূর্ণাঙ্গ অনলাইন অ্যাপ নয়।
পোস্ট, পোল, পছন্দ ও প্রোফাইল localStorage-এ এই ডিভাইসেই থাকে।
কোনো বাস্তব Login/Signup, Cloud Database, বন্ধু-অনুসন্ধান, Online Messaging,
Media Upload, Push Notification, Admin Authentication বা বাস্তব AI API নেই।
WaFi এখানে offline sample replies দেয়; এটি বাস্তব AI নয়।
বাস্তব ব্যবহারকারীর তথ্য বা পাসওয়ার্ড এই প্রোটোটাইপে দেবে না।

পরবর্তী Production পর্যায়ের জন্য দরকার
- নিরাপদ Authentication ও Backend
- Database, file storage, access-control rules
- Server-side admin role ও moderation
- AI API key server-side সংরক্ষণ (কখনো browser-এ নয়)
- Privacy policy, reporting/blocking, abuse prevention
- HTTPS hosting, backups, security testing
