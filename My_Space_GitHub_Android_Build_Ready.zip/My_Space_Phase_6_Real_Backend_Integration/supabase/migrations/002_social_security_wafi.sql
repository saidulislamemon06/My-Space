-- My Space Phase 5: social, moderation and WaFi security hardening.
-- Apply AFTER 001_initial_schema.sql. Review with a qualified developer before launch.

-- 1) Protect the verified flag from all normal client updates.
create or replace function public.guard_verified_flag()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  if new.is_verified is distinct from old.is_verified
     and coalesce(auth.role(), '') <> 'service_role' then
    raise exception 'Verified status can only be changed by the trusted admin service';
  end if;
  return new;
end;
$$;

drop trigger if exists protect_verified_flag on public.profiles;
create trigger protect_verified_flag
before update on public.profiles
for each row execute function public.guard_verified_flag();

-- 2) Tighten friendship transitions: requester creates; addressee accepts/declines;
-- either participant may remove the relationship. Blocking is handled by trusted server.
drop policy if exists "friendships_update_participant" on public.friendships;
create policy "friendships_addressee_decision" on public.friendships
for update to authenticated
using (addressee_id = auth.uid() and status = 'pending')
with check (addressee_id = auth.uid() and status in ('accepted','declined'));

-- 3) Require an accepted friendship for private messaging.
drop policy if exists "messages_send_self" on public.messages;
create policy "messages_send_to_friend" on public.messages
for insert to authenticated
with check (
  sender_id = auth.uid()
  and exists (
    select 1 from public.friendships f
    where f.status = 'accepted'
      and ((f.requester_id = auth.uid() and f.addressee_id = recipient_id)
        or (f.addressee_id = auth.uid() and f.requester_id = recipient_id))
  )
);

-- Users may only update read_at on messages addressed to them; body and identities stay immutable.
drop policy if exists "messages_recipient_update" on public.messages;
create policy "messages_recipient_mark_read" on public.messages
for update to authenticated
using (recipient_id = auth.uid())
with check (
  recipient_id = auth.uid()
  and sender_id = (select m.sender_id from public.messages m where m.id = messages.id)
  and body = (select m.body from public.messages m where m.id = messages.id)
);

-- 4) Basic block list. A block prevents new requests/messages in application logic;
-- read policies expose only rows involving the signed-in user.
create table if not exists public.user_blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id),
  check (blocker_id <> blocked_id)
);
alter table public.user_blocks enable row level security;
create policy "blocks_read_own" on public.user_blocks
for select to authenticated using (blocker_id = auth.uid());
create policy "blocks_create_own" on public.user_blocks
for insert to authenticated with check (blocker_id = auth.uid());
create policy "blocks_delete_own" on public.user_blocks
for delete to authenticated using (blocker_id = auth.uid());

-- 5) Private media metadata. Actual bucket must be created as PRIVATE in Supabase Storage.
create table if not exists public.media_items (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  storage_path text not null unique,
  media_type text not null check (media_type in ('image','video')),
  visibility text not null default 'private' check (visibility in ('private','friends','public')),
  created_at timestamptz not null default now()
);
alter table public.media_items enable row level security;
create policy "media_owner_all" on public.media_items
for all to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());

-- 6) Admin-only verification RPC. Admin role must be assigned by a trusted operator
-- in auth.users.app_metadata; never use user_metadata or client-supplied role fields.
create or replace function public.admin_set_verified(target_user uuid, verified boolean)
returns void language plpgsql security definer set search_path = public
as $$
begin
  if coalesce(auth.jwt() -> 'app_metadata' ->> 'role', '') <> 'admin' then
    raise exception 'Not authorized';
  end if;
  update public.profiles set is_verified = verified, updated_at = now()
  where id = target_user;
  if not found then raise exception 'User not found'; end if;
end;
$$;
revoke all on function public.admin_set_verified(uuid, boolean) from public, anon;
grant execute on function public.admin_set_verified(uuid, boolean) to authenticated;

-- 7) Realtime: enable only the messages table if it is not already published.
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'messages'
  ) then
    alter publication supabase_realtime add table public.messages;
  end if;
exception when undefined_object then
  raise notice 'Realtime publication unavailable; enable it in Supabase Dashboard later.';
end $$;

-- IMPORTANT: This migration is a starter, not a complete security audit.
-- Add rate limits, moderation workflows, age-appropriate defaults and abuse monitoring.
