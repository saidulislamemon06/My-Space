-- My Space Phase 3: Supabase schema with Row Level Security.
-- Apply this migration to a NEW Supabase project after reviewing it.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null check (char_length(username) between 3 and 24),
  display_name text not null default 'My Space User' check (char_length(display_name) <= 40),
  bio text not null default '' check (char_length(bio) <= 160),
  avatar_path text,
  is_verified boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 3000),
  visibility text not null default 'public' check (visibility in ('public','friends','private')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.friendships (
  id uuid primary key default gen_random_uuid(),
  requester_id uuid not null references public.profiles(id) on delete cascade,
  addressee_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','declined','blocked')),
  created_at timestamptz not null default now(),
  unique(requester_id, addressee_id),
  check (requester_id <> addressee_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 5000),
  created_at timestamptz not null default now(),
  read_at timestamptz,
  check (sender_id <> recipient_id)
);

create table if not exists public.polls (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  question text not null check (char_length(question) between 5 and 240),
  options jsonb not null check (jsonb_typeof(options) = 'array' and jsonb_array_length(options) between 2 and 6),
  created_at timestamptz not null default now()
);

create table if not exists public.poll_votes (
  id uuid primary key default gen_random_uuid(),
  poll_id uuid not null references public.polls(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  option_index int not null check (option_index between 0 and 5),
  created_at timestamptz not null default now(),
  unique(poll_id, user_id)
);

create table if not exists public.bookmarks (
  user_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id, post_id)
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  target_type text not null check (target_type in ('post','profile','message')),
  target_id uuid not null,
  reason text not null check (char_length(reason) between 5 and 1000),
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  created_at timestamptz not null default now()
);

create table if not exists public.wafi_memory (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  memory_text text not null check (char_length(memory_text) between 1 and 500),
  user_approved boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists posts_user_created_idx on public.posts(user_id, created_at desc);
create index if not exists messages_pair_created_idx on public.messages(sender_id, recipient_id, created_at desc);
create index if not exists friendships_addressee_status_idx on public.friendships(addressee_id, status);
create index if not exists polls_created_idx on public.polls(created_at desc);

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.friendships enable row level security;
alter table public.messages enable row level security;
alter table public.polls enable row level security;
alter table public.poll_votes enable row level security;
alter table public.bookmarks enable row level security;
alter table public.reports enable row level security;
alter table public.wafi_memory enable row level security;

-- Profiles: signed-in users can view basic profiles; only owners can edit their own.
create policy "profiles_select_authenticated" on public.profiles for select to authenticated using (true);
create policy "profiles_insert_self" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "profiles_update_self" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- Posts: public posts are visible to signed-in users; private posts only to owner.
create policy "posts_read_visibility" on public.posts for select to authenticated using (
  user_id = auth.uid() or visibility = 'public' or
  (visibility = 'friends' and exists (
    select 1 from public.friendships f
    where f.status = 'accepted'
      and ((f.requester_id = auth.uid() and f.addressee_id = posts.user_id)
        or (f.addressee_id = auth.uid() and f.requester_id = posts.user_id))
  ))
);
create policy "posts_insert_self" on public.posts for insert to authenticated with check (user_id = auth.uid());
create policy "posts_update_self" on public.posts for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "posts_delete_self" on public.posts for delete to authenticated using (user_id = auth.uid());

-- Friendship participants only; prevent arbitrary edits by other users.
create policy "friendships_read_participant" on public.friendships for select to authenticated using (requester_id = auth.uid() or addressee_id = auth.uid());
create policy "friendships_request_self" on public.friendships for insert to authenticated with check (requester_id = auth.uid());
create policy "friendships_update_participant" on public.friendships for update to authenticated using (requester_id = auth.uid() or addressee_id = auth.uid()) with check (requester_id = auth.uid() or addressee_id = auth.uid());
create policy "friendships_delete_participant" on public.friendships for delete to authenticated using (requester_id = auth.uid() or addressee_id = auth.uid());

-- Messages can only be read by sender/recipient; sender creates; recipient can update read_at.
create policy "messages_read_participant" on public.messages for select to authenticated using (sender_id = auth.uid() or recipient_id = auth.uid());
create policy "messages_send_self" on public.messages for insert to authenticated with check (sender_id = auth.uid());
create policy "messages_recipient_update" on public.messages for update to authenticated using (recipient_id = auth.uid()) with check (recipient_id = auth.uid());

create policy "polls_read_authenticated" on public.polls for select to authenticated using (true);
create policy "polls_create_self" on public.polls for insert to authenticated with check (user_id = auth.uid());
create policy "polls_update_self" on public.polls for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "polls_delete_self" on public.polls for delete to authenticated using (user_id = auth.uid());
create policy "votes_read_authenticated" on public.poll_votes for select to authenticated using (true);
create policy "votes_insert_self" on public.poll_votes for insert to authenticated with check (user_id = auth.uid());
create policy "votes_update_self" on public.poll_votes for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "bookmarks_owner_all" on public.bookmarks for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Reports: reporter can create/read own report; moderation role must be added server-side later.
create policy "reports_insert_self" on public.reports for insert to authenticated with check (reporter_id = auth.uid());
create policy "reports_read_self" on public.reports for select to authenticated using (reporter_id = auth.uid());

-- WaFi memory is private to its owner and only approved entries are eligible for AI context.
create policy "wafi_memory_owner_select" on public.wafi_memory for select to authenticated using (user_id = auth.uid());
create policy "wafi_memory_owner_insert_approved" on public.wafi_memory for insert to authenticated with check (user_id = auth.uid() and user_approved = true);
create policy "wafi_memory_owner_update" on public.wafi_memory for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "wafi_memory_owner_delete" on public.wafi_memory for delete to authenticated using (user_id = auth.uid());

-- NOTE: verified status must never be writable by normal clients.
-- Keep is_verified out of client profile update forms. Production admin actions
-- must use a server-side privileged function with strict admin authorization.
