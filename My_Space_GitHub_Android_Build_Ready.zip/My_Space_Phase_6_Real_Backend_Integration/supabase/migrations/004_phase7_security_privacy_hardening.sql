-- My Space Phase 7: security/privacy hardening. Apply AFTER 001-003 in staging first.
-- This migration intentionally does not grant client-side admin privileges.
create extension if not exists pgcrypto;

-- Remove broad grants. Existing explicit RLS policies remain the row-level gate.
revoke all on all tables in schema public from anon;
revoke all on all sequences in schema public from anon;

-- Ensure RLS is enabled for all application tables known to this release.
do $$ declare t text; begin
  foreach t in array array['profiles','posts','friendships','messages','polls','poll_votes','bookmarks','user_blocks','wafi_memories','stories','story_views','reels','reel_likes','notifications','media_items','admin_audit_log','reports','wafi_rate_limits'] loop
    if to_regclass('public.'||t) is not null then
      execute format('alter table public.%I enable row level security',t);
    end if;
  end loop;
end $$;

-- Verified state is server-controlled. Client cannot update this column directly.
revoke update (is_verified) on public.profiles from authenticated, anon;

-- Audit trail is append-only for ordinary application roles.
 revoke update, delete, truncate on public.admin_audit_log from anon, authenticated;

-- Constrain media bucket uploads at the Storage layer (private bucket remains private).
update storage.buckets set public=false, file_size_limit=52428800,
  allowed_mime_types=array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm']
where id='my-space-media';

-- Useful indexes for private inbox and expiry cleanup.
create index if not exists messages_recipient_created_idx on public.messages(recipient_id,created_at desc);
create index if not exists messages_sender_created_idx on public.messages(sender_id,created_at desc);
create index if not exists notifications_user_created_idx on public.notifications(user_id,created_at desc);
create index if not exists stories_expiry_owner_idx on public.stories(expires_at,owner_id);

-- Do not expose internal admin audit rows to clients; service role / trusted backend only.
