-- My Space Phase 6 — media, stories/reels, notifications, moderation and admin foundation.
-- Apply after migrations 001 and 002. Review in a staging Supabase project first.
create extension if not exists pgcrypto;

-- User block enforcement is centralized in the database (not just UI logic).
create or replace function public.is_blocked_between(a uuid, b uuid)
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.user_blocks x where
  (x.blocker_id=a and x.blocked_id=b) or (x.blocker_id=b and x.blocked_id=a)); $$;
revoke all on function public.is_blocked_between(uuid,uuid) from public, anon;
grant execute on function public.is_blocked_between(uuid,uuid) to authenticated;

create or replace function public.guard_social_blocks()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  if tg_table_name='friendships' then
    if public.is_blocked_between(new.requester_id,new.addressee_id) then
      raise exception 'Connection unavailable';
    end if;
  elsif tg_table_name='messages' then
    if public.is_blocked_between(new.sender_id,new.recipient_id) then
      raise exception 'Messaging unavailable';
    end if;
  end if;
  return new;
end; $$;
drop trigger if exists friendships_block_guard on public.friendships;
create trigger friendships_block_guard before insert or update on public.friendships
for each row execute function public.guard_social_blocks();
drop trigger if exists messages_block_guard on public.messages;
create trigger messages_block_guard before insert on public.messages
for each row execute function public.guard_social_blocks();

-- Stories and reels use a private Storage bucket. No public object URLs are exposed.
create table if not exists public.stories (
 id uuid primary key default gen_random_uuid(), owner_id uuid not null references public.profiles(id) on delete cascade,
 media_path text not null unique, caption text not null default '' check(char_length(caption)<=300),
 media_type text not null check(media_type in ('image','video')),
 visibility text not null default 'friends' check(visibility in ('friends','public')),
 expires_at timestamptz not null default (now()+interval '24 hours'), created_at timestamptz not null default now()
);
create index if not exists stories_active_idx on public.stories(expires_at desc);
create table if not exists public.story_views (
 story_id uuid not null references public.stories(id) on delete cascade,
 viewer_id uuid not null references public.profiles(id) on delete cascade,
 viewed_at timestamptz not null default now(), primary key(story_id,viewer_id)
);
create table if not exists public.reels (
 id uuid primary key default gen_random_uuid(), owner_id uuid not null references public.profiles(id) on delete cascade,
 media_path text not null unique, caption text not null default '' check(char_length(caption)<=1000),
 visibility text not null default 'friends' check(visibility in ('friends','public')),
 created_at timestamptz not null default now()
);
create table if not exists public.reel_likes (
 reel_id uuid not null references public.reels(id) on delete cascade,
 user_id uuid not null references public.profiles(id) on delete cascade,
 created_at timestamptz not null default now(), primary key(reel_id,user_id)
);

alter table public.stories enable row level security;
alter table public.story_views enable row level security;
alter table public.reels enable row level security;
alter table public.reel_likes enable row level security;

drop policy if exists stories_read_visible on public.stories;
create policy stories_read_visible on public.stories for select to authenticated using (
 owner_id=auth.uid() or (expires_at>now() and not public.is_blocked_between(owner_id,auth.uid()) and
 (visibility='public' or exists(select 1 from public.friendships f where f.status='accepted' and
 ((f.requester_id=auth.uid() and f.addressee_id=owner_id) or (f.addressee_id=auth.uid() and f.requester_id=owner_id)))))
);
create policy stories_owner_insert on public.stories for insert to authenticated with check(owner_id=auth.uid());
create policy stories_owner_update on public.stories for update to authenticated using(owner_id=auth.uid()) with check(owner_id=auth.uid());
create policy stories_owner_delete on public.stories for delete to authenticated using(owner_id=auth.uid());
create policy story_views_read_participant on public.story_views for select to authenticated using(
 viewer_id=auth.uid() or exists(select 1 from public.stories s where s.id=story_id and s.owner_id=auth.uid()));
create policy story_views_insert_self on public.story_views for insert to authenticated with check(viewer_id=auth.uid());
create policy reels_read_visible on public.reels for select to authenticated using(
 owner_id=auth.uid() or (not public.is_blocked_between(owner_id,auth.uid()) and
 (visibility='public' or exists(select 1 from public.friendships f where f.status='accepted' and
 ((f.requester_id=auth.uid() and f.addressee_id=owner_id) or (f.addressee_id=auth.uid() and f.requester_id=owner_id))))));
create policy reels_owner_insert on public.reels for insert to authenticated with check(owner_id=auth.uid());
create policy reels_owner_update on public.reels for update to authenticated using(owner_id=auth.uid()) with check(owner_id=auth.uid());
create policy reels_owner_delete on public.reels for delete to authenticated using(owner_id=auth.uid());
create policy reel_likes_read_authenticated on public.reel_likes for select to authenticated using(true);
create policy reel_likes_insert_self on public.reel_likes for insert to authenticated with check(user_id=auth.uid());
create policy reel_likes_delete_self on public.reel_likes for delete to authenticated using(user_id=auth.uid());

-- Notifications are recipient-private; users can mark their own notifications read.
create table if not exists public.notifications (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
 actor_id uuid references public.profiles(id) on delete set null,
 kind text not null check(kind in ('friend_request','friend_accepted','message','story','reel_like','post','system')),
 entity_id uuid, title text not null check(char_length(title)<=120), body text not null default '' check(char_length(body)<=300),
 read_at timestamptz, created_at timestamptz not null default now()
);
create index if not exists notifications_user_created_idx on public.notifications(user_id,created_at desc);
alter table public.notifications enable row level security;
create policy notifications_read_own on public.notifications for select to authenticated using(user_id=auth.uid());
create policy notifications_update_own on public.notifications for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());

create or replace function public.notify_friend_request()
returns trigger language plpgsql security definer set search_path=public
as $$ begin
 if new.status='pending' then insert into public.notifications(user_id,actor_id,kind,entity_id,title,body)
 values(new.addressee_id,new.requester_id,'friend_request',new.id,'নতুন Friend Request','তোমাকে Friend Request পাঠানো হয়েছে।'); end if;
 return new; end; $$;
drop trigger if exists trg_notify_friend_request on public.friendships;
create trigger trg_notify_friend_request after insert on public.friendships for each row execute function public.notify_friend_request();
create or replace function public.notify_friend_accepted()
returns trigger language plpgsql security definer set search_path=public
as $$ begin
 if old.status='pending' and new.status='accepted' then insert into public.notifications(user_id,actor_id,kind,entity_id,title,body)
 values(new.requester_id,new.addressee_id,'friend_accepted',new.id,'Friend Request accepted','তোমার Friend Request গ্রহণ করা হয়েছে।'); end if;
 return new; end; $$;
drop trigger if exists trg_notify_friend_accepted on public.friendships;
create trigger trg_notify_friend_accepted after update on public.friendships for each row execute function public.notify_friend_accepted();
create or replace function public.notify_message()
returns trigger language plpgsql security definer set search_path=public
as $$ begin insert into public.notifications(user_id,actor_id,kind,entity_id,title,body)
 values(new.recipient_id,new.sender_id,'message',new.id,'নতুন Message','তোমার কাছে একটি নতুন Message এসেছে।'); return new; end; $$;
drop trigger if exists trg_notify_message on public.messages;
create trigger trg_notify_message after insert on public.messages for each row execute function public.notify_message();

-- Moderation queue: reports remain private to reporter; moderators/admins can triage.
alter table public.reports add column if not exists reviewed_by uuid references public.profiles(id) on delete set null;
alter table public.reports add column if not exists reviewed_at timestamptz;
alter table public.reports add column if not exists moderator_note text not null default '';
drop policy if exists reports_admin_read on public.reports;
create policy reports_admin_read on public.reports for select to authenticated using(
 coalesce(auth.jwt()->'app_metadata'->>'role','') in ('admin','moderator'));
drop policy if exists reports_admin_update on public.reports;
create policy reports_admin_update on public.reports for update to authenticated
 using(coalesce(auth.jwt()->'app_metadata'->>'role','') in ('admin','moderator'))
 with check(coalesce(auth.jwt()->'app_metadata'->>'role','') in ('admin','moderator'));

create table if not exists public.admin_audit_log (
 id bigint generated always as identity primary key, actor_id uuid references auth.users(id) on delete set null,
 action text not null, target_type text not null, target_id text not null, details jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now()
);
alter table public.admin_audit_log enable row level security;
create policy admin_audit_read_admin on public.admin_audit_log for select to authenticated
 using(coalesce(auth.jwt()->'app_metadata'->>'role','')='admin');
revoke insert,update,delete on public.admin_audit_log from anon,authenticated;

-- Rate limiting for WaFi Edge Function; service role only.
create table if not exists public.wafi_rate_limits (
 user_id uuid not null references auth.users(id) on delete cascade, window_started_at timestamptz not null,
 request_count integer not null default 0, primary key(user_id,window_started_at)
);
alter table public.wafi_rate_limits enable row level security;
revoke all on public.wafi_rate_limits from anon,authenticated;

-- Storage bucket stays PRIVATE. Client uploads are confined to their own UID folder.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('my-space-media','my-space-media',false,52428800,array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm'])
on conflict(id) do update set public=false,file_size_limit=52428800,allowed_mime_types=excluded.allowed_mime_types;
drop policy if exists my_space_media_owner_select on storage.objects;
create policy my_space_media_owner_select on storage.objects for select to authenticated
 using(bucket_id='my-space-media' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists my_space_media_owner_insert on storage.objects;
create policy my_space_media_owner_insert on storage.objects for insert to authenticated
 with check(bucket_id='my-space-media' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists my_space_media_owner_update on storage.objects;
create policy my_space_media_owner_update on storage.objects for update to authenticated
 using(bucket_id='my-space-media' and (storage.foldername(name))[1]=auth.uid()::text)
 with check(bucket_id='my-space-media' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists my_space_media_owner_delete on storage.objects;
create policy my_space_media_owner_delete on storage.objects for delete to authenticated
 using(bucket_id='my-space-media' and (storage.foldername(name))[1]=auth.uid()::text);

-- Admin RPC for moderation decisions; verified flag remains admin-only.
create or replace function public.admin_review_report(report_uuid uuid, new_status text, note text default '')
returns void language plpgsql security definer set search_path=public
as $$ begin
 if coalesce(auth.jwt()->'app_metadata'->>'role','') not in ('admin','moderator') then raise exception 'Not authorized'; end if;
 if new_status not in ('reviewing','resolved','dismissed') then raise exception 'Invalid status'; end if;
 update public.reports set status=new_status,reviewed_by=auth.uid(),reviewed_at=now(),moderator_note=left(note,1000) where id=report_uuid;
 if not found then raise exception 'Report not found'; end if;
 insert into public.admin_audit_log(actor_id,action,target_type,target_id,details)
 values(auth.uid(),'review_report','report',report_uuid::text,jsonb_build_object('status',new_status));
end; $$;
revoke all on function public.admin_review_report(uuid,text,text) from public,anon;
grant execute on function public.admin_review_report(uuid,text,text) to authenticated;

-- Realtime subscriptions for notifications; enable if publication exists.
do $$ begin
 if exists(select 1 from pg_publication where pubname='supabase_realtime') and not exists(
  select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='notifications') then
  alter publication supabase_realtime add table public.notifications;
 end if;
exception when undefined_object then raise notice 'Realtime publication unavailable'; end $$;

-- Privacy defaults: profile rows are private unless the owner opts into wider visibility.
alter table public.profiles add column if not exists profile_visibility text not null default 'private'
 check(profile_visibility in ('private','friends','public'));
drop policy if exists profiles_select_authenticated on public.profiles;
create policy profiles_select_privacy on public.profiles for select to authenticated using (
 id=auth.uid() or profile_visibility='public' or
 (profile_visibility='friends' and exists(select 1 from public.friendships f where f.status='accepted' and
 ((f.requester_id=auth.uid() and f.addressee_id=profiles.id) or (f.addressee_id=auth.uid() and f.requester_id=profiles.id))))
);
-- Username discovery reveals only a minimal directory card, not the private profile row.
create or replace function public.search_people(search_term text)
returns table(id uuid, username text, display_name text, is_verified boolean)
language sql stable security definer set search_path=public
as $$
 select p.id,p.username,p.display_name,p.is_verified from public.profiles p
 where auth.uid() is not null and p.id<>auth.uid()
 and (p.username ilike '%'||left(trim(coalesce(search_term,'')),24)||'%' or p.display_name ilike '%'||left(trim(coalesce(search_term,'')),40)||'%')
 and not public.is_blocked_between(auth.uid(),p.id)
 order by p.username limit 20;
$$;
revoke all on function public.search_people(text) from public,anon;
grant execute on function public.search_people(text) to authenticated;

-- Prevent notification clients from changing the notification payload or recipient.
create or replace function public.guard_notification_update()
returns trigger language plpgsql set search_path=public
as $$ begin
 if new.user_id is distinct from old.user_id or new.actor_id is distinct from old.actor_id or
    new.kind is distinct from old.kind or new.entity_id is distinct from old.entity_id or
    new.title is distinct from old.title or new.body is distinct from old.body or
    new.created_at is distinct from old.created_at then raise exception 'Notification content is immutable'; end if;
 return new; end; $$;
drop trigger if exists notifications_immutable on public.notifications;
create trigger notifications_immutable before update on public.notifications for each row execute function public.guard_notification_update();

-- Enforce a maximum 24-hour story lifetime regardless of client input.
create or replace function public.clamp_story_expiry()
returns trigger language plpgsql set search_path=public
as $$ begin
 if new.expires_at>now()+interval '24 hours' or new.expires_at<=now() then
  new.expires_at:=now()+interval '24 hours';
 end if;
 return new; end; $$;
drop trigger if exists stories_expiry_guard on public.stories;
create trigger stories_expiry_guard before insert or update of expires_at on public.stories
for each row execute function public.clamp_story_expiry();

-- Views/likes can only be created for content the caller can actually read.
drop policy if exists story_views_insert_self on public.story_views;
create policy story_views_insert_self on public.story_views for insert to authenticated with check(
 viewer_id=auth.uid() and exists(select 1 from public.stories s where s.id=story_id));
drop policy if exists reel_likes_insert_self on public.reel_likes;
create policy reel_likes_insert_self on public.reel_likes for insert to authenticated with check(
 user_id=auth.uid() and exists(select 1 from public.reels r where r.id=reel_id));

-- Gallery media can be shared through metadata visibility, while the Storage bucket stays private.
drop policy if exists media_owner_all on public.media_items;
create policy media_owner_select on public.media_items for select to authenticated using(owner_id=auth.uid());
create policy media_shared_select on public.media_items for select to authenticated using(
 not public.is_blocked_between(owner_id,auth.uid()) and
 (visibility='public' or (visibility='friends' and exists(select 1 from public.friendships f where f.status='accepted' and
 ((f.requester_id=auth.uid() and f.addressee_id=media_items.owner_id) or (f.addressee_id=auth.uid() and f.requester_id=media_items.owner_id)))))
);
create policy media_owner_insert on public.media_items for insert to authenticated with check(owner_id=auth.uid());
create policy media_owner_update on public.media_items for update to authenticated using(owner_id=auth.uid()) with check(owner_id=auth.uid());
create policy media_owner_delete on public.media_items for delete to authenticated using(owner_id=auth.uid());
