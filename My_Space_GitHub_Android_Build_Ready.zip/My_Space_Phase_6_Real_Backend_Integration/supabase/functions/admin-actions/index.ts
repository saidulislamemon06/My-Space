import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import { corsHeaders } from "../_shared/cors.ts";
const json=(v:unknown,s=200)=>new Response(JSON.stringify(v),{status:s,headers:{...corsHeaders,"Content-Type":"application/json"}});
Deno.serve(async(req)=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:corsHeaders});
 if(req.method!=="POST")return json({error:"Method not allowed"},405);
 const h=req.headers.get("Authorization")||""; if(!h.startsWith("Bearer "))return json({error:"Sign in required"},401);
 const url=Deno.env.get("SUPABASE_URL")!,anon=Deno.env.get("SUPABASE_ANON_KEY")!,key=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
 const auth=createClient(url,anon,{global:{headers:{Authorization:h}},auth:{persistSession:false}});
 const {data:{user}}=await auth.auth.getUser(); if(!user)return json({error:"Invalid session"},401);
 const role=user.app_metadata?.role; if(!["admin","moderator"].includes(role))return json({error:"Admin access required"},403);
 let b:any;try{b=await req.json()}catch{return json({error:"Invalid JSON"},400)}
 const db=createClient(url,key,{auth:{persistSession:false}});
 if(b.action==="set_verified" && typeof b.userId==="string" && typeof b.verified==="boolean"){
  if(role!=="admin")return json({error:"Only admins can change verified status"},403);
  const {error}=await db.from("profiles").update({is_verified:b.verified,updated_at:new Date().toISOString()}).eq("id",b.userId);
  if(error)return json({error:error.message},400);
  await db.from("admin_audit_log").insert({actor_id:user.id,action:b.verified?"verify_user":"revoke_verified",target_type:"profile",target_id:b.userId});
  return json({ok:true});
 }
 if(b.action==="review_report" && typeof b.reportId==="string" && ["reviewing","resolved","dismissed"].includes(b.status)){
  const {error}=await auth.rpc("admin_review_report",{report_uuid:b.reportId,new_status:b.status,note:String(b.note||"").slice(0,1000)});
  if(error)return json({error:error.message},400); return json({ok:true});
 }
 return json({error:"Unsupported admin action"},400);
});
