import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import { corsHeaders } from "../_shared/cors.ts";
const json=(v:unknown,s=200)=>new Response(JSON.stringify(v),{status:s,headers:{...corsHeaders,"Content-Type":"application/json"}});
Deno.serve(async(req)=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:corsHeaders});
 if(req.method!=="POST")return json({error:"Method not allowed"},405);
 const h=req.headers.get("Authorization")||"";if(!h.startsWith("Bearer "))return json({error:"Sign in required"},401);
 const url=Deno.env.get("SUPABASE_URL")!,anon=Deno.env.get("SUPABASE_ANON_KEY")!,key=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
 const userClient=createClient(url,anon,{global:{headers:{Authorization:h}},auth:{persistSession:false}});
 const {data:{user}}=await userClient.auth.getUser();if(!user)return json({error:"Invalid session"},401);
 let b:any;try{b=await req.json()}catch{return json({error:"Invalid JSON"},400)}
 if(typeof b.id!=="string"||!['story','reel','gallery'].includes(b.kind))return json({error:"Invalid media reference"},400);
 const table=b.kind==='story'?'stories':b.kind==='reel'?'reels':'media_items';
 const pathColumn=b.kind==='gallery'?'storage_path':'media_path';
 const {data,error}=await userClient.from(table).select(pathColumn).eq('id',b.id).maybeSingle();
 const mediaPath=data?.[pathColumn];
 if(error||!mediaPath)return json({error:"Media unavailable"},404);
 const admin=createClient(url,key,{auth:{persistSession:false}});
 const {data:signed,error:signError}=await admin.storage.from('my-space-media').createSignedUrl(mediaPath,300);
 if(signError||!signed?.signedUrl)return json({error:"Could not open media"},500);
 return json({url:signed.signedUrl,expiresIn:300});
});
