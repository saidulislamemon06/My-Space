# Phase 8 — Final Testing & Release QA

## Automated local checks
`python3 tests/release_checks.py` চালাও। এটি package integrity, required source files, no embedded service-role/provider secret, JWT verification config, PWA manifest ও migration presence যাচাই করে। এটি live backend test নয়।

## Staging test matrix
- Auth: signup, confirmation, signin, signout, expired session, password reset
- Social: create/edit/delete post; friend request accept/decline; block/unblock
- Messages: accepted-friend-only send, recipient read status, block enforcement
- WaFi: approved memory included; unapproved memory excluded; no cross-user data; moderation and rate-limit
- Media: allowed/blocked MIME, 50 MB limit, private signed URL expiry, owner-only delete
- Stories: 24-hour expiry and visibility; reels likes and access
- Notifications: event creation, read state, no cross-user access
- Admin: moderator report review; admin-only verification; audit event
- Privacy: data export/delete, account closure, consent withdrawal
- PWA/Android: install, update, offline shell, deep links, rotation, keyboard, photo picker, notification permission

Record device/browser, build hash, test account role, expected/actual result and evidence. Critical/high defects block release. Never use real personal data in staging.
