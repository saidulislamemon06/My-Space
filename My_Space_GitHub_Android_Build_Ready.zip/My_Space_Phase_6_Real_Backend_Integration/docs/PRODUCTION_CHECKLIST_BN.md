# My Space — Production Readiness Checklist (বাংলা)

## Backend foundation
- [ ] Supabase project owner এবং billing/usage alerts নির্ধারণ
- [ ] Migration SQL review, staging-এ apply, automated tests
- [ ] Auth signup/login/logout/password reset + email verification
- [ ] RLS tests: user A কখনো user B-এর private data পড়তে/লিখতে পারবে না
- [ ] Account deletion ও data export flow

## Security
- [ ] Service-role key, AI API key কেবল server secrets-এ
- [ ] Rate limiting, abuse prevention, input validation
- [ ] HTTPS, secure headers, dependency updates, backups
- [ ] Admin role server-side; client থেকে role/verified flag পরিবর্তন অসম্ভব
- [ ] Admin audit log এবং least-privilege access

## Social features
- [ ] Friend request accept/decline/block
- [ ] Feed visibility enforcement server-side
- [ ] Messaging realtime subscription + block/report safeguards
- [ ] Media storage bucket policies; file size/type validation
- [ ] Poll option index validation এবং duplicate-vote prevention

## WaFi
- [ ] AI calls only through authenticated Edge Function
- [ ] User-approved memory retrieval only
- [ ] Memory review/edit/delete controls
- [ ] Never expose private user data to other users
- [ ] Age-appropriate safety filters and rate limits
- [ ] Explain AI limitations and obtain consent before storing memory

## Launch
- [ ] Privacy policy, community rules, report/block flows
- [ ] Accessibility and Android device testing
- [ ] Staging QA, security review, restore test
- [ ] Closed beta before public release
- [ ] Monitoring and incident response plan

**Status:** Phase 3 starter only. Nothing in this package has been deployed or security-audited.
