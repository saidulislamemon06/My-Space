# My Space Phase 4 — Auth Integration Starter

## যুক্ত হয়েছে
- Sign in / Create account modal
- Supabase Auth client initialization
- Session restore এবং Sign out
- নতুন user-এর জন্য profile row তৈরি করার চেষ্টা
- Signed-in user-এর public cloud posts পড়া
- নতুন local post Supabase-এ mirror করার চেষ্টা
- Supabase configuration না থাকলে স্পষ্ট Offline Demo status

## চালু করার আগে
1. `supabase/migrations/001_initial_schema.sql` একটি Supabase project-এ review করে apply করো।
2. `supabase-config.js`-এ Project URL এবং anon/public key বসাও।
3. Supabase Auth settings-এ Email provider চালু করো; confirmation email ও redirect URL configure করো।
4. ওয়েবসাইট HTTPS hosting-এ deploy করো। Supabase auth redirects-এ সেই domain allow করো।
5. `index.html`-এ CDN থেকে Supabase JS v2 লোড হয়; তাই Preview-তে internet লাগবে।
6. signup/login এবং RLS-এ আলাদা test user দিয়ে পরীক্ষা করো।

## অত্যন্ত গুরুত্বপূর্ণ
- `anon/public` key browser-এ ব্যবহারের জন্য; তবুও RLS অপরিহার্য।
- `service_role` key বা AI API key কখনো `supabase-config.js`, HTML বা JS-এ বসাবে না।
- এই প্যাকেজে Supabase project credentials নেই এবং কোনো live backend তৈরি/deploy করা হয়নি।
- Signup confirmation চালু থাকলে প্রথমে email verify করতে হবে; sign-in-এর পর profile row তৈরি হবে।
- Phase 2-এর profile, bookmarks, poll votes, messages ইত্যাদি এখনও local demo; এই ধাপে কেবল Auth এবং public post-এর সীমিত cloud bridge যোগ হয়েছে।
- Cloud post sync public visibility-তে; friends/private feed policy এবং edit/delete flows পরবর্তী কাজ।
- Schema ও policies production security audit পায়নি। Public launch-এর আগে security review আবশ্যক।

## বয়স ও নিরাপত্তা
My Space-এ অপ্রাপ্তবয়স্ক ব্যবহারকারী থাকতে পারে। Public release-এর আগে উপযুক্ত অভিভাবকীয়/আইনি পর্যালোচনা, age-appropriate privacy defaults, reporting/blocking, moderation, data retention ও deletion ব্যবস্থা যোগ করতে হবে।
