# My Space — Phase 5: Social, Privacy & Admin Foundation

এই প্যাকেজে Phase 4-এর ওপর কয়েকটি backend foundation যোগ করা হয়েছে।

## কী যোগ হয়েছে
- Friend request পাঠানো এবং গ্রহণ/প্রত্যাখ্যানের client helper
- Accepted friends-এর মধ্যে private message পাঠানো
- Conversation load এবং read status helper
- User block list-এর প্রাথমিক ব্যবস্থা
- Private media metadata table
- Verified badge-এর জন্য admin-only database function
- `is_verified` field-কে সাধারণ client update থেকে রক্ষা করার trigger
- Messages table-এর জন্য Realtime publication setup
- Database access-এ Row Level Security (RLS)

## ইনস্টল
1. Supabase Dashboard → SQL Editor খোলো।
2. Phase 3-এর `001_initial_schema.sql` আগে apply করা থাকতে হবে।
3. এরপর `002_social_security_wafi.sql` পুরোটা review করে apply করো।
4. `supabase-config.js`-এ Project URL এবং anon/public key বসাও।
5. `index.html`-এ `social-bridge.js` script যুক্ত আছে—ফাইলটি একই folder-এ রাখবে।
6. HTTPS hosting-এ deploy করার আগে test project-এ পরীক্ষা করো।

## JavaScript ব্যবহার
Sign-in করা অবস্থায় browser console বা app module থেকে:
```js
await MySpaceSocial.sendFriendRequest("TARGET_USER_UUID");
await MySpaceSocial.decideFriendRequest("REQUEST_UUID", "accepted");
const friends = await MySpaceSocial.listFriends();
await MySpaceSocial.sendMessage("FRIEND_USER_UUID", "হ্যালো!");
const messages = await MySpaceSocial.loadConversation("FRIEND_USER_UUID");
await MySpaceSocial.markMessageRead("MESSAGE_UUID");
await MySpaceSocial.blockUser("USER_UUID");
```
এগুলো developer helper; এখনো সম্পূর্ণ Friends বা Messages screen নয়।

## WaFi AI — নিরাপদ পরবর্তী সংযোগ
এই Phase-এ কোনো AI API key রাখা হয়নি এবং কোনো live AI call নেই। WaFi-এর জন্য পরের ধাপে Supabase Edge Function তৈরি করতে হবে:
- API key শুধু server-side secret হিসেবে থাকবে।
- Request-এর user identity Supabase verified JWT থেকে নিতে হবে।
- `wafi_memory` থেকে শুধু `user_approved = true` memory পড়তে হবে।
- অন্য ব্যবহারকারীর private memory, private messages বা private media prompt-এ পাঠানো যাবে না।
- Rate limit, moderation এবং abuse logging যোগ করতে হবে।

## Admin / Verified Badge
`admin_set_verified()` কেবল `auth.users.app_metadata.role = "admin"` হলে চলবে।
- Admin role trusted server/operator দিয়ে assign করতে হবে।
- `user_metadata` বা browser UI থেকে admin role নেওয়া যাবে না।
- Service-role key কখনো browser code, GitHub public repo বা APK-তে রাখা যাবে না।
- Admin approval/revoke action-এ audit log এবং দুই-ধাপ যাচাই যোগ করা উচিত।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি starter integration; live backend নয়।
- SQL production security audit পাস করেনি।
- Block table নিজে থেকে সব query আটকে দেয় না; UI এবং server-side policies-এ block enforcement আরও সম্পূর্ণ করতে হবে।
- Message helper শুধু accepted friendship-এ message পাঠায়; moderation, realtime UI, attachments, typing status এখনো নেই।
- Media table কেবল metadata; private Storage bucket এবং signed URL workflow আলাদা করে configure করতে হবে।
- Teen users-এর জন্য default private profile, message request controls, report/block access, content moderation এবং adult-safe community rules launch-এর আগে আবশ্যক।
