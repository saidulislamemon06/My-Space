# Phase 7 — Security, Privacy & Moderation Hardening

এই ধাপে migration `004_phase7_security_privacy_hardening.sql`, hosting security headers এবং production control checklist যোগ হয়েছে।

## Apply
1. Supabase staging-এ Phase 3 `001`, Phase 5 `002`, Phase 6 `003` ক্রমানুসারে আগে apply থাকতে হবে।
2. `004` SQL review করে staging-এ apply করো। Schema/table name mismatch থাকলে আগে migration reconcile করতে হবে।
3. Supabase Auth-এ email confirmation, strong password policy, redirect allowlist ও leaked-password protection configure করো।
4. Storage bucket private রাখো; upload MIME/size validation server-side-এও enforce করো।
5. Admin ও moderator role কেবল trusted server-side `app_metadata` দিয়ে assign করো; client metadata-কে বিশ্বাস করো না। Verified badge শুধু admin action path-এ।
6. Report queue, block, appeal, account export/deletion, retention এবং incident response manual test করো।

## Launch gate
- RLS negative tests (অন্যের profile private field, messages, media, memories)
- Auth session expiry / token refresh / account recovery
- Rate limit, abuse report escalation, spam and upload abuse
- Audit log tamper resistance
- Backup restore drill এবং data deletion verification
- Privacy notice, age-appropriate experience ও guardian/escalation policy

এই SQL একা পূর্ণ আইনগত compliance বা security certification নয়। Production-এ যাওয়ার আগে independent security review প্রয়োজন।
