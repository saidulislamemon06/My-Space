# Phase 9 — PWA & Android Readiness

- Updated Web App Manifest, app icons and versioned service worker shell cache.
- Service worker explicitly avoids caching Supabase REST/Auth/Functions endpoints.
- Added static-host security headers template (`_headers`). Verify CSP against the actual deployed host and remove any unused domains.
- Added Capacitor configuration and Android build instructions.

## PWA deploy
Serve over HTTPS, ensure manifest/icons resolve, register service worker, test install prompt on supported browsers, verify update flow and offline shell. PWA push requires separate push service setup and permission UX.

## Android release
Capacitor Android wrapper is a source scaffold. Run the steps in `ANDROID_BUILD_BN.md`, test on real devices, configure push provider if needed, sign AAB, complete Play Console policy/Data Safety and age/content declarations. Do not publish until privacy, moderation, account deletion and support channels are live.
