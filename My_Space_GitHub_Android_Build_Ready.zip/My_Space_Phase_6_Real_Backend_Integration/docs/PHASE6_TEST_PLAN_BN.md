# Phase 6 Test Plan

## Automated/static checks
- ZIP integrity: `unzip -t My_Space_Phase_6_Real_Backend_Integration.zip`
- JavaScript syntax: `node --check supabase-bridge.js`, `node --check social-bridge.js`, `node --check wafi-bridge.js`, `node --check media-bridge.js`, `node --check social-plus-bridge.js`
- SQL static review: confirm all new tables have RLS; no frontend service key; storage bucket `public=false`; approved memory filter appears in WaFi function.

## Supabase staging checks (requires project credentials)
1. Apply migrations 001 → 002 → 003 on a disposable staging project.
2. Test two normal users: profile isolation, request/accept/decline, messaging only after accepted friendship, block prevents both new requests and messages.
3. Test notifications: request, acceptance and message create recipient-only notifications; read status only by recipient.
4. Test media: unauthenticated upload denied; user A cannot list/download/delete user B's object; max size and MIME restrictions enforced; signed URL expires.
5. Test stories/reels: owner can manage; friends/public visibility follows RLS; expired stories are not returned; blocked users cannot read.
6. Test WaFi: no session → 401; invalid JWT → 401; over-limit → 429; flagged request rejected; only caller's approved memory is loaded; unapproved and other-user memory are absent; provider key never appears in browser network payload/source.
7. Test admin: normal user cannot call admin Edge Function; moderator can review report but cannot set verified; admin can verify/revoke and audit event is written.
8. Verify Realtime subscriptions with two users; verify notification payloads do not include message body.

## Not run in this environment
No Supabase project credentials or deployed Edge Functions were provided, so database migrations, live API calls, RLS behavior, realtime delivery and device testing cannot be truthfully marked passed.
