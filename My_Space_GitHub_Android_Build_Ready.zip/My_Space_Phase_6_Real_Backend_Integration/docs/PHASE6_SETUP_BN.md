# My Space — Phase 6 বাস্তব Backend Integration

এই প্যাকেজ Phase 5-এর Supabase starter-এর ওপর তৈরি। আগের UI theme/layout পুনর্লিখন করা হয়নি; নতুন integration আলাদা bridge ও Edge Function-এ রাখা হয়েছে। Phase 6 ফাইলগুলো backend code, client bridge, migration ও setup guide—এগুলো যোগ করলেই কোনো backend স্বয়ংক্রিয়ভাবে Live হয় না।

## এই Phase-এ যা যোগ হয়েছে

- **WaFi AI:** authenticated Supabase Edge Function; OpenAI API key server-side secret; input/output provider moderation; প্রতি user-এ ১২ request/minute limit; WaFi prompt-এ শুধু ঐ user-এর `user_approved=true` memory; private message, অন্য user-এর memory বা gallery data prompt-এ যায় না। Chat history server-এ সংরক্ষণ করা হয় না।
- **Gallery/media:** private Storage bucket, UID-scoped upload path, ৫০ MB cap, MIME allowlist, metadata CRUD, short-lived signed URL.
- **Stories/Reels:** ২৪ ঘণ্টার story expiry, visibility (friends/public), story views, reels, likes এবং RLS; viewer access যাচাই করে signed media URL দেওয়া হয়।
- **Notifications:** private inbox, friend request/accept ও message notification trigger, read status.
- **Friends/Messages:** minimal profile discovery RPC, incoming/outgoing requests, accepted friends, conversation list, message send/read, block/unblock; database trigger block-এর বিপরীতে নতুন connection/message আটকায়। Profile visibility default `private`; owner চাইলে `friends` বা `public` করতে পারে (`MySpaceSocialPlus.setProfileVisibility('friends')`).
- **Admin/Moderation:** report triage RPC, audit log, admin-only verified badge operation (শুধু `app_metadata.role=admin`), admin action Edge Function.

## ইনস্টল করার ক্রম

1. Phase 3 `001_initial_schema.sql` এবং Phase 5 `002_social_security_wafi.sql` আগে apply থাকতে হবে।
2. Supabase SQL Editor-এ `supabase/migrations/003_phase6_media_stories_notifications_admin.sql` review করে apply করো।
3. `supabase/config.toml`-এ নিচের function configuration রাখো (JWT verification enabled):

```toml
[functions.wafi-chat]
verify_jwt = true
[functions.media-access]
verify_jwt = true
[functions.admin-actions]
verify_jwt = true
```

4. Supabase CLI দিয়ে functions deploy করো:

```bash
supabase functions deploy wafi-chat
supabase functions deploy media-access
supabase functions deploy admin-actions
```

5. Supabase → Project Settings → API / Edge Functions Secrets-এ সেট করো:

```bash
supabase secrets set OPENAI_API_KEY=YOUR_SERVER_SIDE_KEY
supabase secrets set WAFI_MODEL=gpt-4o-mini
supabase secrets set APP_ORIGIN=https://YOUR-APP-DOMAIN.example
```

`SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` Edge Functions-এর runtime secrets/environment-এ Supabase সরবরাহ করবে। প্রয়োজন হলে dashboard-এ নিশ্চিত করো। **Service role key, OpenAI key কখনো `supabase-config.js`, frontend, Git repo বা APK-তে বসাবে না।**

6. `supabase-config.js`-এ শুধু Project URL ও anon/public key বসাও। `index.html`-এর শেষের দিকে Phase 5 script-এর পরে নিচের script যোগ করো:

```html
<script src="wafi-bridge.js"></script>
<script src="media-bridge.js"></script>
<script src="social-plus-bridge.js"></script>
```

7. Trusted operator Supabase Auth user-এর `app_metadata.role` server-side Admin UI/secure server দিয়ে `admin` (বা moderation-এর জন্য `moderator`) সেট করবে। Moderator report review করতে পারবে; verified badge কেবল `admin` দিতে/বাতিল করতে পারবে। Client-side `user_metadata` কখনো role authority নয়। Admin role assign করার কোনো public UI এই package-এ নেই।

## Client API

```js
await MySpaceWaFi.ask('আমাকে একটি পড়ার পরিকল্পনা সাজাতে সাহায্য করো');
await MySpaceWaFi.addApprovedMemory('আমি বাংলা ভাষায় উত্তর পছন্দ করি');
await MySpaceWaFi.listApprovedMemory();
await MySpaceMedia.upload(file, { visibility: 'private' });
await MySpaceMedia.createStory(file, 'আজকের মুহূর্ত', 'friends');
await MySpaceMedia.listStories();
await MySpaceMedia.createReel(file, 'আমার Reel', 'friends');
await MySpaceMedia.viewUrl('story', storyId);
await MySpaceSocialPlus.searchPeople('emon');
await MySpaceSocialPlus.requests();
await MySpaceSocialPlus.friends();
await MySpaceSocialPlus.sendMessage(friendId, 'হ্যালো');
await MySpaceSocialPlus.notifications();
await MySpaceSocialPlus.report('profile', profileId, 'রিপোর্টের কারণ');
await MySpaceSocialPlus.adminAction('set_verified', {userId, verified:true});
```

## Security / launch blockers

- Phase 3/4/5-এর SQL-ও staging-এ security review ছাড়া production-এ চালানো যাবে না। Phase 6 migration profiles-এর default visibility private করে এবং minimal search RPC দেয়; তবু profile fields/avatars-এর field-level privacy ও user testing আলাদা করে review করতে হবে।
- Existing Phase 5 `messages` read policy participant-only হলেও message content moderation, attachment scanning, spam throttling, conversation deletion/export ও message request workflow এখনো সম্পূর্ণ নয়।
- Media bucket private। Gallery owner-এর media list/upload/delete করতে পারবে; story/reel viewer-কে RLS যাচাইয়ের পর ৫ মিনিটের signed URL দেওয়া হয়। Signed URL expiry-র পরে আবার request করতে হবে।
- Stories/reels-এর DB metadata access policy friends/public অনুযায়ী; storage path raw public URL নয়।
- Story expiry background cleanup-এর জন্য Supabase Cron/pg_cron job configure করতে হবে; expired story select-এ আর আসে না, কিন্তু row ও file নিজে থেকে delete হয় না।
- Notifications realtime publication enable করা হয়েছে; client realtime subscription UI আলাদা করে wire করতে হবে।
- Admin audit log insert service-role/admin trusted code ছাড়া client থেকে করা যায় না। Verified badge শুধু Admin action route থেকে বদলাবে।
- WaFi-তে approved memory-ও sensitive তথ্য হতে পারে। UI-তে প্রতিটি memory review/delete, clear consent, rate-limit monitoring, cost cap, provider retention review এবং age-appropriate policy launch-এর আগে নিশ্চিত করো।
- App-টি teen ব্যবহারকারীদেরও ব্যবহারযোগ্য হতে পারে ধরে default private profile, guardian/age policy, report/block UX, content review, data deletion/export, abuse escalation ও incident response ছাড়া public launch নয়।

## Status

এটি **Phase 6 integration package / deploy-ready source starter**, Live deployment নয়। Supabase project, secrets, domain, trusted Admin role এবং staging verification ছাড়া কোনো feature Live বলা যাবে না।
