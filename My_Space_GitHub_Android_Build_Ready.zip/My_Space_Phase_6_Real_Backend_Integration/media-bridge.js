/* Private gallery uploads: files live under <auth.uid()>/<uuid> in a private bucket. */
(() => {
 const BUCKET='my-space-media';
 function sb(){const c=window.mySpaceSupabaseClient;if(!c)throw new Error('Supabase configuration ও Sign in প্রয়োজন।');return c;}
 async function upload(file,{visibility='private'}={}){const c=sb(),{data:{user}}=await c.auth.getUser();if(!user)throw new Error('Sign in required');
  if(!(file instanceof File))throw new Error('একটি ফাইল নির্বাচন করো');
  if(!['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm'].includes(file.type))throw new Error('এই ফাইল ফরম্যাট সমর্থিত নয়।');
  if(file.size>50*1024*1024)throw new Error('ফাইল সর্বোচ্চ ৫০ MB হতে পারবে।');
  const ext=(file.name.split('.').pop()||'bin').toLowerCase().replace(/[^a-z0-9]/g,'');const path=`${user.id}/${crypto.randomUUID()}.${ext}`;
  const {error:upErr}=await c.storage.from(BUCKET).upload(path,file,{contentType:file.type,upsert:false});if(upErr)throw upErr;
  const mediaType=file.type.startsWith('video/')?'video':'image';
  const {data,error}=await c.from('media_items').insert({owner_id:user.id,storage_path:path,media_type:mediaType,visibility}).select().single();
  if(error){await c.storage.from(BUCKET).remove([path]);throw error;}return data;
 }
 async function list(){const {data,error}=await sb().from('media_items').select('*').order('created_at',{ascending:false});if(error)throw error;return data||[];}
 async function signedUrl(path,expiresIn=300){const {data,error}=await sb().storage.from(BUCKET).createSignedUrl(path,Math.min(Math.max(expiresIn,60),3600));if(error)throw error;return data.signedUrl;}
 async function remove(id,path){const c=sb();const {error}=await c.from('media_items').delete().eq('id',id);if(error)throw error;const {error:storageError}=await c.storage.from(BUCKET).remove([path]);if(storageError)throw storageError;}
 async function createStory(file,caption='',visibility='friends'){const item=await upload(file,{visibility:'private'});const {data,error}=await sb().from('stories').insert({owner_id:item.owner_id,media_path:item.storage_path,media_type:item.media_type,caption:String(caption).slice(0,300),visibility}).select().single();if(error)throw error;return data;}
 async function listStories(){const {data,error}=await sb().from('stories').select('*,profiles:owner_id(display_name,username,avatar_path)').gt('expires_at',new Date().toISOString()).order('created_at',{ascending:false});if(error)throw error;return data||[];}
 async function createReel(file,caption='',visibility='friends'){const item=await upload(file,{visibility:'private'});const {data,error}=await sb().from('reels').insert({owner_id:item.owner_id,media_path:item.storage_path,caption:String(caption).slice(0,1000),visibility}).select().single();if(error)throw error;return data;}
 async function listReels(){const {data,error}=await sb().from('reels').select('*,profiles:owner_id(display_name,username,avatar_path)').order('created_at',{ascending:false}).limit(50);if(error)throw error;return data||[];}
 async function viewUrl(kind,id){const {data,error}=await sb().functions.invoke('media-access',{body:{kind,id}});if(error)throw error;if(data?.error)throw new Error(data.error);return data.url;}
 async function likeReel(reelId){const c=sb(),{data:{user}}=await c.auth.getUser();const {error}=await c.from('reel_likes').upsert({reel_id:reelId,user_id:user.id},{onConflict:'reel_id,user_id'});if(error)throw error;}
 window.MySpaceMedia={upload,list,signedUrl,remove,createStory,listStories,createReel,listReels,viewUrl,likeReel};
})();
