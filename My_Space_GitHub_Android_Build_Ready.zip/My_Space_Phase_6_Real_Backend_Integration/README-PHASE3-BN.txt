MY SPACE — PHASE 3 BACKEND STARTER
===================================

এই প্যাকেজে Phase 2 frontend-এর সঙ্গে Supabase backend schema starter যুক্ত করা হয়েছে।

ফোল্ডার:
- index.html / styles.css / app.js: Phase 2 frontend
- supabase/migrations/001_initial_schema.sql: database tables + Row Level Security policies
- supabase/.env.example: configuration template (কোনো real secret নেই)
- docs/PRODUCTION_CHECKLIST_BN.md: production launch checklist

এটি এখনো live backend নয়।
কোনো Supabase project তৈরি, deploy, বা account connect করা হয়নি।
SQL migration প্রয়োগ না করা পর্যন্ত online login/database চালু হবে না।

পরবর্তী সেটআপ:
1. একজন অভিভাবক/বিশ্বস্ত প্রাপ্তবয়স্কের সহায়তায় Supabase project তৈরি ও ownership পরিচালনা করো।
2. SQL Editor-এ migration ফাইলের SQL review করে run করো।
3. Auth-এ email confirmation, rate limits ও secure redirect URLs সেট করো।
4. Frontend-এ Supabase URL + public anon key configure করো; service_role key কখনো browser-এ নয়।
5. RLS policies পরীক্ষা না করে public launch কোরো না।
6. Admin actions server-side function-এ implement করতে হবে; client থেকে is_verified পরিবর্তন নিষিদ্ধ রাখতে হবে।

Privacy:
- Messages sender/recipient ছাড়া অন্য কেউ পড়তে পারে না।
- WaFi memory owner-only; কেবল user-approved memory-ই AI context-এ ব্যবহারযোগ্য হবে।
- Verified badge normal user client থেকে পরিবর্তন করা যাবে না।
- Report records reporter-only; moderation workflow আলাদা server-side role লাগবে।

বর্তমান Phase 2 frontend এখনও localStorage ডেমো হিসেবে চলে। এই schema নিজে থেকে সেটিকে online করে না।

Phase 4: Auth UI + Supabase Auth bridge starter files: supabase-config.js, supabase-bridge.js, docs/PHASE4_AUTH_SETUP_BN.md. Not live until configured and deployed.
