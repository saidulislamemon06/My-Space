# My Space — ফ্রি Cloud Android Build

এই সোর্সে GitHub Actions workflow যোগ করা হয়েছে। এটি GitHub-এর runner-এ Node.js, Java 17 ও Android build tools ব্যবহার করে **debug APK** তৈরি করবে। এই workflow নিজে থেকে কোনো Play Store release বা signed production APK তৈরি করে না।

## একবার তোমার যা করতে হবে
1. ZIP extract করে পুরো `My_Space_Phase_6_Real_Backend_Integration` ফোল্ডারের ফাইলগুলো নিজের GitHub repository-তে upload করতে হবে। Repository-র নাম `main` branch-এ রাখতে পারো।
2. GitHub repository-র **Actions** tab-এ গিয়ে **Build My Space Android APK** workflow খুলে **Run workflow** চাপতে হবে। `main` branch-এ push করলেও workflow চলবে।
3. Build সফল হলে workflow run-এর নিচে **Artifacts** থেকে `My-Space-debug-apk` নামের artifact নামিয়ে extract করে `app-debug.apk` Android ফোনে install করা যাবে।

## সীমা
- এটি debug/test APK; production signing key/keystore তৈরি বা সংরক্ষণ করে না।
- GitHub-এ source upload ও workflow চালানোর অনুমতি তোমাকেই দিতে হবে; আমি তোমার GitHub account-এ নিজে থেকে ঢুকতে পারি না।
- APK তৈরি হলেও real login, email redirect, media upload, notifications এবং AI-র live end-to-end test আলাদাভাবে করতে হবে।
- কোনো service-role key বা AI secret GitHub source-এ যোগ করবে না।
