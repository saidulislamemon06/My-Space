MY SPACE — PHASE 5 STARTER

নতুন ফাইল:
- supabase/migrations/002_social_security_wafi.sql
- social-bridge.js
- docs/PHASE5_SOCIAL_AI_ADMIN_BN.md

এটি Phase 4 Auth Starter-এর ওপর তৈরি।
এখনো live/deployed নয়। প্রথমে Phase 3 migration, তারপর Phase 5 migration
Supabase test project-এ apply ও security review করতে হবে।

কোনো API secret বা service-role key frontend-এ যোগ করবে না।
বিস্তারিত নির্দেশনা docs/PHASE5_SOCIAL_AI_ADMIN_BN.md ফাইলে।
