/* My Space cloud profile, polls and bookmarks. RLS remains the authority. */
(() => {
  'use strict';
  const client=()=>{const c=window.mySpaceSupabaseClient;if(!c)throw new Error('Supabase সংযোগ ও Sign in প্রয়োজন।');return c;};
  async function me(){const {data:{user},error}=await client().auth.getUser();if(error)throw error;if(!user)throw new Error('আগে Sign in করো।');return user;}
  async function getProfile(){const u=await me();const {data,error}=await client().from('profiles').select('id,username,display_name,bio,avatar_path,is_verified,profile_visibility').eq('id',u.id).single();if(error)throw error;return data;}
  async function updateProfile({display_name,bio,profile_visibility}){const u=await me();const patch={display_name:String(display_name||'').trim().slice(0,60),bio:String(bio||'').trim().slice(0,300)};if(profile_visibility)patch.profile_visibility=profile_visibility;const {data,error}=await client().from('profiles').update(patch).eq('id',u.id).select().single();if(error)throw error;return data;}
  async function listPolls(){const {data,error}=await client().from('polls').select('id,user_id,question,options,created_at').order('created_at',{ascending:false}).limit(50);if(error)throw error;return data||[];}
  async function createPoll(question,options){const u=await me();const q=String(question||'').trim();const opts=(options||[]).map(x=>String(x||'').trim()).filter(Boolean);if(q.length<5||q.length>240||opts.length<2||opts.length>6||opts.some(x=>x.length>80))throw new Error('প্রশ্ন ৫–২৪০ অক্ষর এবং ২–৬টি অপশন দিতে হবে।');const {data,error}=await client().from('polls').insert({user_id:u.id,question:q,options:opts}).select().single();if(error)throw error;return data;}
  async function vote(pollId,optionIndex){const u=await me();const {data,error}=await client().from('poll_votes').upsert({poll_id:pollId,user_id:u.id,option_index:optionIndex},{onConflict:'poll_id,user_id'}).select().single();if(error)throw error;return data;}
  async function pollResults(pollId){const {data,error}=await client().from('poll_votes').select('option_index').eq('poll_id',pollId);if(error)throw error;return (data||[]).reduce((a,x)=>(a[x.option_index]=(a[x.option_index]||0)+1,a),{});}
  async function myVote(pollId){const u=await me();const {data,error}=await client().from('poll_votes').select('option_index').eq('poll_id',pollId).eq('user_id',u.id).maybeSingle();if(error)throw error;return data?.option_index??null;}
  async function savePost(postId){const u=await me();const {error}=await client().from('bookmarks').upsert({user_id:u.id,post_id:postId},{onConflict:'user_id,post_id'});if(error)throw error;}
  async function removeSavedPost(postId){const u=await me();const {error}=await client().from('bookmarks').delete().eq('user_id',u.id).eq('post_id',postId);if(error)throw error;}
  async function savedPosts(){const {data,error}=await client().from('bookmarks').select('post_id,created_at,posts(id,body,created_at,user_id,profiles(display_name,username))').order('created_at',{ascending:false});if(error)throw error;return data||[];}
  window.MySpaceCloudFeatures={getProfile,updateProfile,listPolls,createPoll,vote,pollResults,myVote,savePost,removeSavedPost,savedPosts};
})();
